/**
 * Combines class names based on various inputs (strings, objects, arrays).
 * @param {...any[]} args - Class name inputs (strings, objects, arrays).
 * @returns {string} A string of combined class names.
 */
export const tukClassify = (...args: any[]): string => {
    const classes: string[] = [];

    args.forEach((arg) => {
        if (typeof arg === "string") {
            classes.push(arg);
        } else if (Array.isArray(arg)) {
            classes.push(tukClassify(...arg));
        } else if (typeof arg === "object" && arg !== null) {
            Object.keys(arg).forEach((key) => {
                if (arg[key]) {
                    classes.push(key);
                }
            });
        }
    });

    return classes.join(" ");
};
