import {
    CreateCustomerValidationConstant,
    EMPTY_OBJECT,
    EMPTY_STRING, IMEI,
    MAX_LENGTH_OF_BANK_ACCOUNT_NAME,
    MIN_AGE,
    NUMBER_ELEVEN, NUMBER_ONE,
    NUMBER_SEVEN_IN_STRING,
    NUMBER_SIX,
    NUMBER_TEN,
    NUMBERS,
    PARAMS_TYPES, SIM_CARD_NUMBER,
    UNDEFINED, Regex
} from "../constants";
import { RegxType } from "../types";

const { ZERO } = NUMBERS;

/**
 * Checks if the given parameter is undefined or null.
 * @param {any} param - The parameter to check.
 * @returns {boolean} True if the parameter is undefined or null, otherwise false.
 */
export const isUndefinedOrNull = (param: any): boolean => param === undefined || param === null;

/**
 * Checks if the given variable is a boolean.
 * @param {any} variable - The variable to check.
 * @returns {boolean} True if the variable is a boolean, otherwise false.
 */
export const isBoolean = (variable: any): boolean => typeof variable === PARAMS_TYPES.BOOLEAN;

/**
 * Checks if the given parameter is undefined, null, or empty (0 for numbers).
 * @param {string | number} [param] - The parameter to check.
 * @returns {boolean} True if the parameter is undefined, null, or empty, otherwise false.
 */
export const isUndefinedOrNullOrEmpty = (param?: string | number): boolean =>
    param === undefined || param == null || param === ZERO;

/**
 * Checks if the given parameter is an empty object.
 * @param {any} param - The parameter to check.
 * @returns {boolean} True if the parameter is an empty object, otherwise false.
 */
export const isEmptyObject = (param: any): boolean => Object.keys(param || {}).length === ZERO;

/**
 * Validates if the given value is required.
 * @param {any} value - The value to validate.
 * @returns {string | undefined} Returns 'Required' if the value is invalid, otherwise undefined.
 */
export const required = (value: any): string | undefined =>
    value || typeof value === PARAMS_TYPES.NUMBER ? undefined : 'Required';

/**
 * Validates if the given value is a required field.
 * @param {any} value - The value to validate.
 * @returns {string | undefined} Returns 'Required field' if the value is invalid, otherwise undefined.
 */
export const requiredField = (value: any): string | undefined =>
    value || typeof value === PARAMS_TYPES.NUMBER ? undefined : 'Required field';

/**
 * Validates if the given value is a required field with a custom error message.
 * @param {string} errorMsg - The custom error message.
 * @returns {(value: any) => string | undefined} A function that validates the value.
 */
export const requiredFieldWithError = (errorMsg: string) => (value: any): string | undefined =>
    value || typeof value === PARAMS_TYPES.NUMBER ? undefined : errorMsg;

/**
 * Validates if the given value is within a specified range of employees.
 * @param {string} errorMsg - The error message to return if validation fails.
 * @param {number} minRange - The minimum range value.
 * @param {number} maxRange - The maximum range value.
 * @returns {(value: any) => string | undefined} A function that validates the value.
 */
export const numberOfEmployeesRange = (errorMsg: string, minRange: number, maxRange: number) => (value: any): string | undefined =>
    value && value >= minRange && value <= maxRange ? undefined : errorMsg;

/**
 * Validates if the given value does not exceed the maximum length.
 * @param {any} value - The value to validate.
 * @returns {string | undefined} Returns an error message if the value exceeds the maximum length, otherwise undefined.
 */
export const maxLength = (value: any): string | undefined =>
    value && value.length > 15 ? `Must be ${15} characters or less` : undefined;

/**
 * It should have 1 to 6 words.
 * Words can contain letters (both uppercase and lowercase).
 * Words can have spaces, hyphens ('-'), single quotes ('''), question marks ('?'), or double quotes ('"').
 * The input should not end with a space.
 * @param value
 * @returns {string | undefined} - Validation message or undefined incase it is valid
 */
export const acountHolderError = (value: any) => {
    if (!value) {
        return 'Please enter the account holder name.';
    }

    if (value && value.length > 1 && /^[A-Za-z-'`"\s]+$/i.test(value)) {
        return undefined;
    }
    return 'Your account holder name can only contain letters and these characters (-, `, ", \') and should be more than 1 characters long.';
};

export const validateBankAccountHolderName = (value: any) => {
    if (!value || !value.trim()) {
        return 'Please enter the account holder name.';
    }
    return (value.length > MAX_LENGTH_OF_BANK_ACCOUNT_NAME) ? `Must be ${MAX_LENGTH_OF_BANK_ACCOUNT_NAME} or less` : undefined;
};

// This Function will receive a string and will return the string without non alphanumeric characters,
// it will also remove +44 prefix that we have for phone numbers and if sort type is present it will not remove prefix
export const convertStringToAlphaNumericOnly = (value: string, sortType?: boolean): string | undefined => {
    let cleanedValue;
    if (typeof value === PARAMS_TYPES.STRING) {
        cleanedValue = sortType ? value.replace(/[^a-zA-Z0-9]/g, EMPTY_STRING) : value.replace(/^\+?44|[^a-zA-Z0-9]/g, EMPTY_STRING);
    }
    return cleanedValue;
};


export const phoneNumberValidation = (errorMsg: string) => (value: string): string | undefined => {
    const prefixPattern = /^(?:\+44\s*\(0\)\s*7|\+4407|\+447|447|\+44\(0\)7)/;
    const cleanedLengthValue = convertStringToAlphaNumericOnly(value);
    const cleanedNumberAfterPatternRemoval = value?.replace(/\s+/g, EMPTY_STRING)?.replace(prefixPattern, EMPTY_STRING)?.trim();

    // below if condition is checking invalid characters that are not digits
    if (/\D/.test(<string>cleanedNumberAfterPatternRemoval)) {
        return errorMsg;
    }
    if (cleanedLengthValue?.startsWith(NUMBER_SEVEN_IN_STRING) && cleanedLengthValue?.length !== NUMBER_TEN) {
        return errorMsg;
    }
    if (cleanedLengthValue?.length !== NUMBER_ELEVEN && !cleanedLengthValue?.startsWith(NUMBER_SEVEN_IN_STRING)) {
        return errorMsg;
    }

    return UNDEFINED;
};

const regxGetterForType = (type: RegxType): RegExp | undefined => {
    const regxPatterns: Record<RegxType, RegExp> = {
        dot: /^[0-9]{2}\.[0-9]{2}\.[0-9]{2}$/,
        dash: /^[0-9]{2}-[0-9]{2}-[0-9]{2}$/,
        space: /^[0-9]{2} [0-9]{2} [0-9]{2}$/,
        forwardSlash: /^[0-9]{2}\/[0-9]{2}\/[0-9]{2}$/,
        backWardSlash: /^[0-9]{2}\\[0-9]{2}\\[0-9]{2}$/,
        plain: /^[0-9]{6}$/,
    };

    return regxPatterns[type];
};

const detectTypeFromValue = (value: string): RegxType => {
    if (value.includes('.')) {
        return 'dot';
    }
    if (value?.includes('-')) {
        return 'dash';
    }
    if (value?.includes(' ')) {
        return 'space';
    }
    if (value?.includes('/')) {
        return 'forwardSlash';
    }
    if (value?.includes('\\')) {
        return 'backWardSlash';
    }
    return 'plain';
};

export const sortCodeValidation = (value: any, props: Record<string, any>): string | null | void => {
    const sortCodeAcceptanceStringType: string | null = detectTypeFromValue(value);
    const sortCodeAcceptanceRegxType: RegExp | undefined = regxGetterForType(sortCodeAcceptanceStringType as RegxType);
    const checkMatch = sortCodeAcceptanceRegxType?.test(value);

    if (!checkMatch) {
        return props?.translate('validations.validSixDigitSortCodeMessage');
    }
    return null;
};

// @ts-ignore
export const bankAccountSortCodeValidation = (value: any, allValues: Record<string, any>, props: Record<string, any>): string | void => {
    const cleanedValue = value?.replace(/[^a-zA-Z0-9]/g, '');

    if (!value || cleanedValue?.length !== NUMBER_SIX) {
        return props?.translate('validations.sortCodeValidationMessage');
    }

    const validationError = sortCodeValidation(value, props);
    return validationError || undefined;
};

export const email = (value: any) => (value && !/^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)
    ? 'Invalid email address'
    : undefined);

export const emailCustomizedMessage = (errorMsg: string) => (value: any) => (value && !/^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)
    ? errorMsg
    : undefined);

export const emailRequiredCustomizedMessage = (errorMsg: string) => (value: any) => (!/^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value)
    ? errorMsg
    : undefined);

export const grossSalaryValidation = (value: any) => {
    if (value && !/^-?[0-9]*$/i.test(value)) {
        return 'Only numbers';
    }
    if (value && value < 0) {
        return 'Number can\'t be lower than 0';
    }
    if (value && value.length > 7) {
        return 'Number can\'t  be greater than 7 digits';
    }
    return undefined;
};

export const emailValidationOnSearchOrder = (value: any) => {
    if (value && value.includes('@')) {
        if ((!/^[A-Z0-9._%-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(value))) {
            return 'Invalid Email address';
        }
    }
    if (value && !value.includes('@') && /[^a-zA-Z0-9 ]/i.test(value)) {
        return 'Only alphanumeric characters ';
    }
    return undefined;
};

export const emailConfirmationCustomizedMessage = (errorMsg: string, emailField: string, section: string) => (value: any, values: any) => {
    const emailToBeCompared = section === EMPTY_STRING ? values?.[emailField] : values?.[section]?.[emailField];
    return value && value.toLowerCase() !== emailToBeCompared?.toLowerCase() ? errorMsg : undefined;
};

export const alphaNumeric = (value: any) => {
    return (value && /[^a-zA-Z0-9 ]/i.test(value)
        ? 'Only alphanumeric characters'
        : undefined);
};

export const alphaNumericCustomizedMessage = (errorMsg: string) => (value: any) => (value && /[^a-zA-Z ]/i.test(value)
    ? errorMsg
    : undefined);

export const onlyDigits = (errorMsg: string) => (value: any) => {
    return (value && /[^0-9 ]/i.test(value)
        ? errorMsg
        : undefined);
};

export const onlyDigitsAndDecimal = (errorMsg: string) => (value: any) => {
    return (value && /[^0-9. ]/i.test(value)
        ? errorMsg
        : undefined);
};

export const firstNameLength = (errorMsg: string) => (value: any) => {
    return (value && /^[a-zA-Z\s]{0,15}$/i.test(value)
        ? undefined
        : errorMsg);
};

export const lastNameLength = (errorMsg: string) => (value: any) => {
    return (value && /^[a-zA-Z\s]{0,30}$/i.test(value)
        ? undefined
        : errorMsg);
};

export const startWithLetters = (errorMsg: string) => (value: any) => {
    return (!value || !(value.match(/^\d/))
        ? undefined
        : errorMsg);
};
export const endWithLetters = (errorMsg: string) => (value: any) => {
    return (!value || !(value.match(/\s$/))
        ? undefined
        : errorMsg);
};

export const valueComparionWithErrorMsg = (eufFee: number, errorMsg: string) => (value: any) => (value > eufFee ? errorMsg : undefined);

export const minLength = (min: number, errorMsg: string) => (value: any) => (value && value.length < min ? errorMsg : undefined);

export const maxLengthWithError = (max: number, errorMsg: string) => (value: any) => (value && value.length > max ? errorMsg : undefined);

export const isNumbersOnly = (value: any) => {
    return value && /^-?[0-9]*$/i.test(value);
};
export const numbersOnly = (errorMsg: string) => (value: any) => {
    return value && !/^-?[0-9]*$/i.test(value) ? errorMsg : undefined;
};
export const numbersOnlyWithMinAndMaxLength = (min: number, max: number) => (value: any) => {
    return new RegExp(`^\\d{${min},${max}}$`).test(value) ? undefined : `Please enter a number between ${min} and ${max}`;
};
export const decimalNumbersAllowed = (errorMsg: string) => (value: any) => {
    return value && !/^-?[0-9.]*$/i.test(value) ? errorMsg : undefined;
};

export const onlyPositiveNumber = (errorMsg: string) => (value: any) => {
    return value && value < 0 ? errorMsg : undefined;
};

export const futureDate = (value: any) => (value && new Date().getFullYear() >= value ? undefined : 'The provided date is too late');

export const phoneNumber = (errorMsg: string) => (value: any) => (value && value.length === 11 ? undefined : errorMsg);

export const phoneNumberForMobileApp = (errorMsg: string) => (value: any) => (value && (value.length === 11 || value.length === 12) ? undefined : errorMsg);

export const pacCode = (errorMsg: string) => (value: any) => (value && value.length <= 9 && /[A-Za-z]{3}[0-9]{6}$/.test(value) ? undefined : errorMsg);

export const stacCode = (errorMsg: string) => (value: any) => (value && value.length <= 9 && /[0-9]{6}[A-Za-z]{3}$/.test(value) ? undefined : errorMsg);

export const isStartWithNumber = (value: any) => (value && /^[0-9].*$/.test(value));

export const requiredValidation = (errorMsg: string) => (value: any) => (value ? undefined : errorMsg);

export const spendCapRequiredPositive = (errorMsg: string) => (value: any) => (value >= 0 ? undefined : errorMsg);

export const spendCapRequiredMaxAmount = (errorMsg: string) => (value: any) => (value >= 0 && value < 999999 ? undefined : errorMsg);

export const postalCodeValidation = (errorMsg: string) => (value: any) => (value && /^[A-Z]{1,2}[0-9R][0-9A-Z]? ?[0-9][ABD-HJLNP-UW-Z]{2}$/i.test(value) ? undefined : errorMsg);

export const postalCodeValidationAdress = (value: any) => (value && /^[A-Z]{1,2}[0-9R][0-9A-Z]? ?[0-9][ABD-HJLNP-UW-Z]{2}$/i.test(value));

export const contactPhoneNumberValidation = (errorMsg: string) => (value: string) => phoneNumberValidation(errorMsg)(value);

export const phoneNumberValidationWithLandline = (errorMsg: string) => (value: string) => (((value && /(^0\d{10})$/.test(value)) || !value) ? undefined : errorMsg);
export const prepayPhoneNumberValidation = (errorMsg: string) => (value: string) => {
    if (!value) {
        return UNDEFINED;
    }
    return phoneNumberValidation(errorMsg)(value);
};

export const laterYearValidation = (errorMsg: string) => (value: any) => {
    const dateValue = new Date(value);
    if (dateValue.getTime() > Date.now()) {
        return errorMsg;
    }

    return undefined;
};

export const monthValidation = (errorMsg: string) => (value: any) => {
    if (value > 12 || value < 1) {
        return errorMsg;
    }

    return undefined;
};

export const minYearValidation = (errorMsg: string) => (value: any) => {
    const date = new Date();
    const maxAge = 140;
    if (typeof value !== 'object' && value < date.getFullYear() - maxAge) {
        return errorMsg;
    }
    const dateValue = new Date(value);

    if (dateValue.getFullYear() < date.getFullYear() - maxAge) {
        return errorMsg;
    }
    return undefined;
};

export const getValidationDatesValues = (values: any, name: string) => {
    const eventTargetNames = name?.split('.');
    const fieldType = eventTargetNames?.[0];
    const fieldName = eventTargetNames?.[1];
    const currentlyChangedMonth = values?.[fieldType]?.month || values?.[fieldType]?.[fieldName]?.month;
    const customerYearOfBirth = values?.YourDetailsSectionName?.dateOfBirth?.year;
    const customerMonthOfBirth = values?.YourDetailsSectionName?.dateOfBirth?.month;

    return { currentlyChangedMonth, customerYearOfBirth, customerMonthOfBirth };
};

// @ts-ignore
export const isCustomerBdayBeforeValidDate = (errorMsg: string) => (value: string, values: any, props: any, name: any) => {
    const { customerYearOfBirth, customerMonthOfBirth, currentlyChangedMonth } = getValidationDatesValues(values, name);
    // eslint-disable-next-line radix
    if ((customerYearOfBirth && parseInt(value) < parseInt(customerYearOfBirth))
        // eslint-disable-next-line radix
        || (customerYearOfBirth && parseInt(value) === parseInt(customerYearOfBirth) && (customerMonthOfBirth && parseInt(currentlyChangedMonth) && (parseInt(currentlyChangedMonth) < customerMonthOfBirth)))) {
        return errorMsg;
    }
    return undefined;
};

// @ts-ignore
export const futureDateValidation = (errorMsg: string) => (value: string, values: any, props: any, name: any) => {
    const { currentlyChangedMonth } = getValidationDatesValues(values, name);

    const currentYear = new Date().getFullYear();
    const currentMonth = new Date().getMonth() + NUMBER_ONE;

    // eslint-disable-next-line radix
    if ((parseInt(value) > currentYear)
        // eslint-disable-next-line radix
        || (parseInt(value) === currentYear && (parseInt(currentlyChangedMonth) && (currentMonth < parseInt(currentlyChangedMonth))))) {
        return errorMsg;
    }
    return undefined;
};

// @ts-ignore
export const employeeUnder16Validation = (errorMsg: string) => (value: string, values: any, props: any, name: any) => {
    const { customerYearOfBirth, customerMonthOfBirth, currentlyChangedMonth } = getValidationDatesValues(values, name);
    const checkInputTypes = () => {
        if (Number(value) && Number(customerYearOfBirth) && Number(currentlyChangedMonth) && Number(customerMonthOfBirth)) {
            // eslint-disable-next-line radix
            return ((parseInt(value) - parseInt(customerYearOfBirth) < 16) || ((parseInt(value) - parseInt(customerYearOfBirth) === 16) && (parseInt(customerMonthOfBirth) > parseInt(currentlyChangedMonth))));
        }
        return false;
    };
    if (checkInputTypes()) {
        return errorMsg;
    }

    return undefined;
};

// @ts-ignore
export const birthDateValidation = (errorMsg: string, dateFormFieldName: string, section: string) => (value: string, values: any) => {
    const { day, month, year } = values?.[section]?.[dateFormFieldName] || EMPTY_OBJECT;
    if (!day || !month || !year) {
        return undefined;
    }
    const dateNowTimeStamp = new Date().getTime();
    const dateNowMonth = new Date(dateNowTimeStamp);

    const birthDateTimeStamp = new Date(`${month}-${day}-${year}`).getTime();
    const birthDateDateType = new Date(birthDateTimeStamp);

    const yearsDiff = dateNowMonth.getFullYear() - birthDateDateType.getFullYear();
    const monthsDiff = dateNowMonth.getMonth() - birthDateDateType.getMonth();
    const daysDiff = dateNowMonth.getDay() - birthDateDateType.getDay();
    if (((yearsDiff === ZERO && monthsDiff < ZERO) || (yearsDiff === ZERO && monthsDiff === ZERO && daysDiff < ZERO)) && daysDiff < MIN_AGE) {
        return errorMsg;
    }
    return undefined;
};

// @ts-ignore
export const dateValidation = (errorMsg: string, dateFormFieldName: string, section: string) => (value: string, values: any) => {
    const dateFormat = Regex.VALID_DATE;

    const availableValue = section === EMPTY_STRING ? values?.[dateFormFieldName] : values?.[section]?.[dateFormFieldName];
    if (!availableValue) {
        return undefined;
    }
    const { day, month, year } = availableValue;
    if (!day || !month || !year) {
        return undefined;
    }
    if ((!dateFormat.test(`${day}/${month}/${year}`))) {
        return errorMsg;
    }

    return undefined;
};

// @ts-ignore
export const dateValidationForPrepay = (errorMsg: string, dateFormFieldName: string, section: string) => (value: string, values: any) => {
    const dateFormat = Regex.VALID_DATE;
    const availableValue = section === EMPTY_STRING ? values?.[dateFormFieldName] : values?.[section]?.[dateFormFieldName];
    if (!availableValue) {
        return undefined;
    }
    const { day, month, year } = availableValue;
    if (!day && !month && !year) {
        return undefined;
    }

    if (day && month && year) {
        if (dateFormat.test(`${day}/${month}/${year}`)) {
            return undefined;
        }
    }
    return errorMsg;
};

export const preventLetters = (event: any) => {
    if (event.which < 48 || event.which > 57) {
        event.preventDefault();
    }
};

export const startWith = (errorMessage: string, prefix: string) => (value: string) => {
    if (value && value.startsWith(prefix)) {
        return undefined;
    }
    return errorMessage;
};

export const isURL = (errorMessage: string) => (value: string) => {
    if (value && (value.startsWith('http://') || value.startsWith('https://'))) {
        return undefined;
    }
    return errorMessage;
};

export const isDuplicateIMEIValue = (errorMessage: string, currentSection: string) => (value: string, values: any) => {
    if (value && values) {
        let ans: string | undefined;
        Object.keys(values).every((sectionName: string) => {
            const sectionValues = values[sectionName];
            const scanFields = Object.keys(sectionValues);
            if (ans) {
                return false;
            }
            scanFields.every((field: string) => {
                if (currentSection !== sectionName && field === IMEI && sectionValues[field] === value) {
                    ans = errorMessage;
                    return false;
                }
                ans = undefined;
                return true;
            });
            return true;
        });
        return ans;
    }
    return errorMessage;
};

export const isDuplicateSimValue = (errorMessage: string, currentSection: string) => (value: string, values: any) => {
    if (value && values) {
        let ans: string | undefined;
        Object.keys(values).every((sectionName: string) => {
            const sectionValues = values[sectionName];
            const scanFields = Object.keys(sectionValues);
            if (ans) {
                return false;
            }
            scanFields.every((field: string) => {
                if (currentSection !== sectionName && field === SIM_CARD_NUMBER && sectionValues[field] === value) {
                    ans = errorMessage;
                    return false;
                }
                ans = undefined;
                return true;
            });
            return true;
        });
        return ans;
    }
    return errorMessage;
};

export const isValidDateObject = (dateObject: { year: string; month: string; day: string }) => {
    if (!dateObject) {
        return false;
    }
    const { day, month, year } = dateObject;
    if (!day || !month || !year) {
        return false;
    }
    return true;
};

export const isValidRangeforDayDate = (errorMsg: string) => (day: string) => {
    if (Number(day) >= CreateCustomerValidationConstant.DAY_MIN_RANGE && Number(day) <= CreateCustomerValidationConstant.DAY_MAX_RANGE) {
        return undefined;
    }
    return errorMsg;
};

export const isValidRangeforMonthDate = (errorMsg: string) => (month: string) => {
    if (Number(month) >= CreateCustomerValidationConstant.MONTH_MIN_RANGE && Number(month) <= CreateCustomerValidationConstant.MONTH_MAX_RANGE) {
        return undefined;
    }
    return errorMsg;
};

export const isValidTopRangeYearDate = (errorMsg: string) => (year: string) => {
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - NUMBER_ONE);
    if (Number(year) <= yesterday.getFullYear()) {
        return undefined;
    }

    return errorMsg;
};

export const isBirthDateUnderEighteen = (errorMsg: string) => (year: string, values: any) => {
    const day = values?.YourDetailsSectionName?.dateOfBirth?.day;
    const month = values?.YourDetailsSectionName?.dateOfBirth?.month;
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    if (day && month) {
        if (Number(year) < today.getFullYear()) return undefined;
        if (Number(year) === today.getFullYear() && Number(month) < (today.getMonth() + 1)) return undefined;
        if (Number(year) === today.getFullYear() && Number(month) === (today.getMonth() + 1) && Number(day) < today.getDate()) return undefined;
    }
    return errorMsg;
};

export const isValidBottomRangeYearDate = (errorMsg: string) => (year: string) => {
    if (Number(year) > CreateCustomerValidationConstant.YEAR_BOTTOM_RANGE) {
        return undefined;
    }
    return errorMsg;
};

// @ts-ignore
export const isBusinessStartDateNotLaterThanToday = (errorMsg: string) => (value: string, values: any) => {
    const today = new Date();
    const day = values?.BusinessDetailsSectionName?.establishDate?.day;
    const month = values?.BusinessDetailsSectionName?.establishDate?.month;
    const year = values?.BusinessDetailsSectionName?.establishDate?.year;
    const businessStartDate = new Date(`${year}-${month}-${day}`);
    if (businessStartDate && businessStartDate.getTime() < today.getTime()) {
        return undefined;
    }
    return errorMsg;
};
