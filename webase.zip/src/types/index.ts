export type { RegxType } from './RegxType.ts';
