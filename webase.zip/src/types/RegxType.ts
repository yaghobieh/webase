export type RegxType = 'dot' | 'dash' | 'space' | 'forwardSlash' | 'backWardSlash' | 'plain';
