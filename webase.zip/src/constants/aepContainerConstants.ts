export const DEEP_LINK_CONTAINERS_ID = {
	CUSTOMER_DASHBOAR_ID: 'personalised-campaigns-account-below-amount-due',
	THREE_UPGRADES_ID: 'personalised-campaigns-upgrade-below-cu-plan',
};

export const AEP_CONTEINERS_ID = {
	GLOABL_CAMPAIGNS_BELOW_MAIN_NAV_ID: 'personalised-campaigns-global-below-main-nav',
	GLOABL_CAMPAIGNS_BELOW_WIZARD_ID: 'personalised-campaigns-below-progress-bar',
	BASCKET_UNDER_REMOVE_LINK_ID: 'personalised-campaigns-basket-line-selection',
	BASCKET_BELLOW_ACCESSORIES_HEAD_ID: 'personalised-campaigns-basket-accessory-selection',
	SIMO_PLANS_X3_SLP_ID: 'personalised-campaigns-slp-above-top-plans',
	PERSONALIZED_CAMPAIN_BELLOW_PROGRESS_BAR_ID: 'personalised-campaigns-below-progress-bar',
	PERSONAL_CAMPAIGNS_BELOW_TERTARY_NAV: 'personalised-campaigns-below-tertiary-nav',
	PERSONALISED_CAMPAIGNS_DLP_BELOW_SORT: 'personalised-campaigns-dlp-below-sort',
	PERSONALISED_CAMPAIGNS_MOD_PROPS: 'personalised-campaigns-mod-props'
};
