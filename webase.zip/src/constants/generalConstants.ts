export enum ACCESSIBLITY_KEYS {
    enter = 'Enter',
    space = 'Space',
    backspace = 'Backspace',
    arrowLeft = 'ArrowLeft',
    arrowRight = 'ArrowRight',
    keydown = 'keydown'
}

export const PAYMENT_OPTION = {
    ONE_TIME: 'oneTime',
    RECURRING: 'recurring',
    TOTAL_RECURRING_DEVICE_FINANCING: 'recurringIncludeDeviceFinancing',
    MONTH: 'month'
};
export const ATTACHMENT_TYPE = {
    IMAGE: 'image',
    TEXT: 'text',
    HTML: 'html'
};
export const ATTACHMENT_PURPOSE = {
    LIST: 'list',
    DETAILS: 'details',
    DIMENSIONS: 'dimensions',
    SUMMARY: 'summary'
};
export const RESPONSE_STATUS = {
    SUCCESS: 'SUCCESS',
    SUCCESS_LOWER_CASE: 'success',
    FAILURE: 'FAILURE',
    ERROR: 'Error',
    FATAL: 'Fatal',
    ERROR_CODE: 'errorCode',
    STATUS: 'status',
    LOADING: 'loading' as const,
    DONE: 'done' as const,
    FAILED: 'failed' as const,
    ERROR_INTERNAL_SERVER_ERROR_STATUS_CODE: 500,
    SUCCESS_STATUS_CODE: 200,
    SUCCESS_WITH_NEW_RESOURCE_STATUS_CODE: 201,
    SUCCESS_WITH_NO_CONTENT_STATUS_CODE: 204,
    SUCCESS_WITH_PARTIAL_RESULTS_STATUS_CODE: 206,
    CONFLICT_STATUS_CODE: 409,
    PAGE_NOT_FOUND: 404,
    ERROR_AUTH_STATUS_CODE: 401,
    ERROR_FORBIDDEN_STATUS_CODE: 403,
    ERROR_BAD_REQUEST_STATUS_CODE: 400
};

export const RESUME_RESPONSE_STATUS = {
    RESUME_SUCCESS: 'success'
};
export enum MEDIA_BREAK_POINTS {
    MOBILE = 'mobile',
    TABLET = 'tablet'
}
export const CUSTOMER_TYPE = {
    BUSINESS: 'business',
    BUSINESS_CUSTOMER: 'businessCustomer',
    INDIVIDUAL: 'individual',
};

export const CUSTOMER_DASHBOARD = 'CUSTOMER_DASHBOARD';
export const CUSTOMER_SUB_TYPE = {
    SME: 'SME'
};
export const IFRAME_INITIAL_VALUE = {
    pspTransactionRef: '',
    transactionsId: '',
    url: ''
};
export const EXISTING_CUSTOMER = 'existingCustomer';
export const ORDER_ID = 'orderId';
export const USER_EMAIL = 'userEmail';
export const ORDER_CREDIT_STATUS = 'orderCreditVettingStatus';
export const MAX_LENGTH_OF_MONTH_FIELD = 2; // Month can be 1 or 2 characters e.g. 1,2,3...10,11,12
export const ZERO_STRING = '0';
export const LEADING_ZERO_FOR_MONTH_AND_YEAR = '000';
export const EMPTY_STRING = '';
export const AUTO = 'auto';
export const STOCK_AVAILABILITY_PARAM = ',stockAvailability';
export const EMPTY_ARRAY = [];
export const EMPTY_OBJECT = {};
export const DISABLE_TEXT = 'disable';
export const SPACE = ' ';
export const COMMA_SPACE = ', ';
export const UNDER_SCORE = '_';
export const PERCENT_SYMBOL = '%';
export const GLOBAL_REPLACE = 'g';
export const QUESTION_MARK = '?';
export const EQUAL_SIGN = '=';
export const AND_SIGN = '&';
export const DOT = '.';
export const PDF_CONTENT_TYPE = 'application/pdf';
export const COMMA = ',';
export const ASTERISK = '*';
export const AT_SIGN = '@';
export const OFF = 'off';
export const LINK_TO_INGRAM_MICRO_SERVICES = 'https://recycle.three.co.uk/';
export const LINK_TO_INGRAM_MICRO_SERVICES_B2B = 'https://businessrecycle.three.co.uk/';
export const LINK_TO_GET_IN_TOUCH = 'https://www.three.co.uk/support/contact-us';
export const INFO_ICON_LINK = 'https://recycle.three.co.uk/';
export const DASH = '--';
export const TWO_DASH = '- -';
export const TITLE_DASH = '-----';
export const SINGLE_DASH = '-';
export const OPEN_PAREN = '(';
export const CLOSE_PAREN = ')';
export const COLON = ':';
export const PLUS = '+';
export const BOOLEAN_TRUE = true;
export const BOOLEAN_FALSE = false;
export const NUMBER_ZERO = 0;
export const NUMBER_NEGATIVE_ONE = -1;
export const NUMBER_ONE = 1;
export const NUMBER_ONE_AND_A_HALF = 1.5;
export const INSURANCE_STR = 'Insurance';
export const INSURANCES_STR = 'insurances';
export const NUMBER_TWO = 2;
export const NUMBER_NEGATIVE_TWO = -2;
export const NUMBER_FOUR = 4;
export const NUMBER_THREE = 3;
export const NUMBER_SEVEN = 7;
export const NUMBER_EIGHT = 8;
export const NUMBER_NINE = 9;
export const NUMBER_FIFTEEN = 15;
export const NUMBER_EIGHTEEN = 18;
export const TWENTY_FIVE = 25;
export const NUMBER_TWENTY = 20;
export const NUMBER_TWENTY_FOUR = 24;
export const NUMBER_TWENTY_EIGHT = 28;
export const MIN_AGE = 18;
export const NUMBER_SIX = 6;
export const NUMBER_FIVE = 5;
export const NUMBER_TWENTY_NINE = 29;
export const NUMBER_THIRTY = 30;
export const NUMBER_FIFTY_EIGHT = 58;
export const NUMBER_SIXTY = 60;
export const NUMBER_SEVENTY_FIVE = 75;
export const NUMBER_THIRTY_ONE = 31;
export const NUMBER_TEN = 10;
export const NUMBER_FIVE_THOUSAND = 5000;
export const NUMBER_ONE_THOUSAND = 1000;
export const NUMBER_ONE_THOUSAND_FIVE_HUNDRED = 1500;
export const NUMBER_TWO_THOUSAND_TWO_HUNDRED_TWENTY_TWO = 2222;
export const NUMBER_TWELVE = 12;
export const NUMBER_NINETEEN = 19;
export const NUMBER_FOURTY = 40;
export const FIRST_INDEX = 0;
export const TWO_HUNDERED_AND_EIGHTEEN = 218;
export const FIFTY = 50;
export const ONE_HUNDERED_AND_FIFTY = 150;
export const EIGHTY = 80;
export const HUNDRED = 100;
export const MAX_AUTH_ZERO_EXT = 255;
export const FOUR_ZERO_DIGITS = '0000';
export const TWO_ZERO_DIGITS = '00';
export const MAX_TOTAL_SUBS = 250;
export const NUMBER_ELEVEN = 11;
export const NINETY_NINE = 99;
export const STRING_NUMBER_ONE = '1';
export const STRING_NUMBER_TWO = '2';
export const STRING_NUMBER_FOUR = '4';
export const THREE_THOUSEND = 3000;
export const TWENTY_TWENTY_FOUR = 2024;
export const ACTIVE = 'active';
export const PREPAY_SIM_ONLY = 'PREPAY - SIM Only';
export const MBB_SIM_ONLY = 'MBB - SIM Only';
export const TICK_SYMBOL = '&#10004;';
export const BREAK_LINE = '\n';
export const ADOBE_LIMIT_CHAR = 75;
export const TRADE_IN_DONE = false;
export const TRADE_IN_ENABLED = true;
export const PAY_OFF_BALANCE = 'payOffBalance';
export const WIZARD = 'wizard';
export const NUMBER_FIVE_HUNDRED = 500;
export const DOUBLE_SPACE = '  ';
export const NUMBER_SEVEN_IN_STRING = '7';
export const TYPE_TELEPHONE = 'tel';
export const EXPONENTIAL_CHARACTER = 'e';
export const ALLOWED_KEYS_FOR_PHONE_NUMBER_ON_KEYDOWN = [ACCESSIBLITY_KEYS.backspace, ACCESSIBLITY_KEYS.arrowLeft, ACCESSIBLITY_KEYS.arrowRight];
export const SKIP_HTML = /<\/?[^>]+(>|$)/g;
export const HEIGHT_OF_BTNS = 84;

export enum PDF_TYPES {
    DATA = 'Data',
    PRINT_DOCUMENT = 'Print Document'
}
export const MAX_LENGTH_OF_BANK_ACCOUNT_NAME = 80;
export enum BUTTON_TYPES {
    BUTTON = 'Button',
    LINK = 'Link',
    SUBMIT = 'submit',
    GOOGLE_PAY = 'googlePay',
    APPLE_PAY = 'applePay'
}

export enum DESCRIPTION_TYPE {
    LINK = 'link',
    STRING = 'string',
    DISCOUNT = 'discount',
}
export const PERMISSIONS = 'PERMISSIONS';
export const PERMISSIONS_STATUSES = {
    VISIBLE: 'visible',
    HIDDEN: 'hidden'
};
export const PERMISSIONS_TYPES = {
    CHANGE_OWNERSHIP: 'change-ownership',
    PREPAY_PAGES: 'showPrepayFUT'
};
export enum MODAL_ACTIONS {
    CLOSE = 'close',
    SUBMIT = 'submit'
}
export const PORT_OUT_OPERATION = {
    PAC: 'PAC',
    STAC: 'STAC',
    ETF: 'ETF',
    GLP_ETF: 'GLP_ETF',

};
export const CHOICE_CARD_FOR_PORT_OUT_OPERATION = [
    {
        id: PORT_OUT_OPERATION.PAC, content: PORT_OUT_OPERATION.PAC, disabled: false
    },
    {
        id: PORT_OUT_OPERATION.STAC, content: PORT_OUT_OPERATION.STAC, disabled: false
    }
];

export const PORT_OUT_POPUPS_DATE_FORMAT = 'D MMM YYYY';
export const PORT_OUT_STATUS_SUCCESS = 'success';
export const ERROR_STATUS = 'error';
export const FULL_DATE_FORMAT = 'Do MMM YYYY';
export const FULL_DATE_WITH_DASHES = 'MM-DD-YYYY';
export const SHORT_YEAR_DATE_FORMAT_WITH_DASHES = 'DD-MMM-YY';
export const FULL_DATE_FORMAT_WITH_SLASH = 'DD/MM/YYYY';

export const ORDERING_ACTIVITY_TYPES = {
    CHANGE_OWNERSHIP: 'changeOwnership',
    NEW_SUBSCRIPTION: 'newSubscription',
    MODIFY_SUBSCRIPTION: 'modifySubscription',
    CHANGE_PLAN: 'changePlan',
    UPGRADE_DEVICE: 'upgradeDevice'
};
export enum DATE_TYPES {
    DEFAULT_FORMAT = 'YYYY-MM-DDTHH:mm:ssZ',
    GENERAL_DATE_FORMAT = 'D MMM YYYY',
    GENERAL_DATE_FORMAT_WITH_COMMA = 'D,MMM,YYYY',
    GENERAL_DATE_FORMAT_WITH_ONE_COMMA = 'D MMM,YYYY',
    GENERAL_DATE_FORMAT_WITH_MONTH_DAY = 'MMM Do, YYYY',
    GENERAL_DATE_FORMAT_FULL_DATE_WIHTOUT_TIME = 'YYYY-MM-DD',
    GENERAL_DATE_FORMAT_DOUBLE_D = 'DD MMM YYYY',
    GENERAL_DATE_FORMAT_DOUBLE_M = 'DD MM YYYY',
    GENERAL_DATE_FORMAT_DOUBLE_M_WITH_SLASH = 'DD/MM/YYYY',
    GENERAL_DATE_FORMAT_SHORT_DAY_NAME = 'ddd',
    GENERAL_DATE_FORMAT_WITH_DOTS = 'DD.MM.YYYY',
    GENERAL_DATE_FORMAT_SHORTEN_WITHOUT_DASHES = 'DDMMYYYY',
    GENERAL_DATE_FORMAT_WITH_TIME = 'D MMMM YYYY HH:mm',
    BASIC_DATE_WITH_MONTH_NAME_WITHOUT_COMMA = 'DD MMM YYYY',
    GENERAL_FULL_DATE_FORMAT = 'DD MMMM YYYY',
    GENERAL_FULL_DATE_FORMAT_WITH_TIME = 'DD MMMM YYYY HH:mm',
    FULL_MONTH_AND_YEAR = 'MMMM YYYY',
    TWO_NUMBERS_DAY_AND_THREE_LETTERS_MONTH = 'DD MMM',
    HOUR_AND_MINUTES = 'hh:mm',
    TWENTY_FOUR_HOUR_AND_MINUTES = 'HH:mm',
    FULL_TIME = 'HH:mm:ss',
    UPDATE_PROFILE_DATE_FORMAT = 'Do MMM, YYYY',
    NUMBERED_DATE = 'Do',
    IST_FORMAT = 'ddd MMM DD HH:mm:ss [IST] YYYY',
    GENERAL_DATE_FORMAT_ONE_COMMA = 'D MMMM, YYYY',
    GENERAL_DATE_FORMAT_SHORT_MONTH_WITH_YEAR = 'MMM YYYY',
    DATE_FORMATTED_WITH_SPACE = 'YYYY-MM-DD HH:mm:ss',
    GENERAL_DATE_FORMAT_DO = 'Do MMMM, YYYY',
    ALLOWANCE_EXPIRY_DATE_FORMAT_WITH_TIME = 'DD MMM YYYY HH:mm',
    FUP_DATA_ALLOWANCE_LAST_UPDATED_DATE = 'DD MMM YYYY',
    FUP_DATA_ALLOWANCE_LAST_UPDATED_TIME = 'HH:mm',
    GENERAL_DAY_DATE_MONTH_FORMAT = 'dddd Do MMMM'
}

export const INVALID_DATE = 'Invalid date';

export enum PHONE_FORMAT_TYPES {
    PHONE_FORMATTER_MASK = 'XXX XXXXXXXXX',
    PHONE_NUMBER_FORMAT_VIEW = '(XXX) XXX XXXX',
    PHONE_FORMAT_WITH_SPACES = 'XXXXX XXX XXXX'
}
export const MONTHS_ARRAY = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export enum CURRENCY_SIGNS {
    GBP = '£',
    USA = '$',
    EUR = '€'
}
export enum CURRENCY_TYPE {
    GBP = 'GBP'
}
export const TIME_LEFT_IN_SESSION_FOR_TEXT_MESSAGE = 1;
export const SESSION_TIMEOUT_PERIOD = 'SESSION_TIMEOUT_PERIOD';

export const REPLACE_CONTACT_VIEW_MODE = {
    CONTACT_DETAILS: 'Contact Details',
    AVAILABLE_CONTACT_LIST: 'Contact List'
};
export const secondInMilliseconds = 1000;

export const minuteInSeconds = 60;

export const secondInHour = 3600;

export const CART_VALIDATION_STATUS = {
    BLOCKED: 'blocked',
    SUCCESS: 'success',
    WARNING: 'warning',
    INFORMATION: 'information'
};
export const CART_VALIDATION_COMPATIBILITY_STATUS = 'compatibility';
export const DUMMY_CART_ID = '1234A';

export const SEND_ICON_SVG = '/assets/images/send-icon.svg';
export const USER_ICON_SVG = '/assets/images/user-icon.svg';
export const STORE_ICON_SVG = '/assets/images/store-with-bg.svg';
export const THREE_LOGO_ICON_SVG = '/assets/images/3logo-with-bg.svg';
export const ATTACHMENT_ICON_SVG = '/assets/images/attachment-icon.svg';
export const SECURE_ICON_SVG = '/assets/images/secure payment.svg';
export const INFO_IMAGE = '/assets/images/SearchCustomer/info_image.svg';
export const LOADING_ANIMATION_GIF = '/assets/gifs/loading_animation_Aurora.gif';
export const ERROR_IMAGE_SVG = '/assets/images/SearchCustomer/error_image.svg';
export const LOCK = '/assets/images/fraud/lock.svg';
export const SPIDER = '/assets/images/fraud/spider.svg';
export const TOPUP_PAYG_SVG = '/assets/images/plan-payg-icon.svg';
export const TRADE_IN_SVG = '/assets/images/tradein-device.svg';
export const TRADE_IN_AVATAR = '/assets/images/tradein-avatar.svg';

export const UTC_STRING = 'UTC';
export const THIRTY_DAYS_COUNT = 30;
export const THIRTY_DAYS_TYPE = 'days';
export const dayMonthFormat = 'DD MMM';
export const completeDateFormat = 'Do MMM, YYYY';

export const EMPLTY_PLACE_FILLER = '';
export const FIRST_NAME_MAX_LENGTH = 30;
export const LAST_NAME_MAX_LENGTH = 30;

export const TRUE = 'true';
export const FALSE = 'false';

export const DEFAULT = 'DEFAULT';

export const START = 'start';

export const SMARTWATCH_PRODUCT_TYPE = 'smartWatch';

export const MANAGE_ACCOUNT_USER = 'Manage account user';

export enum DATE_PARTS {
    DAY = 'day',
    MONTH = 'month',
    YEAR = 'year'
}

export const restErrorMessages = {
    MAXIMUM_MEMBERS_ALLOWED_EXCEEDED_409: 'Max_Limit_Exceeded_409',
    SHARER_GENERAL_ERROR_MESSAGE_500: 'someSharerErrorCode_500',
    GENERAL_ERROR_MESSAGE_500: 'someErrorCode_500',
    CANNOT_COMPLETE_PAYG_FOR_COLLECTION_409: 'Cannot_complete_for_Collection_409',
    ADAPT_LINE_INCOMPATIBLE_LEVEL_PLAN: 'adapt_line_incompatible_level_plan_409',
    ADAPT_LINE_MORE_THAN_ONE_LEVEL_PLAN: 'adapt_Line_More_Than_One_Level_Plan_409',
    CUSTOMER_GET_LOANS_FAILED_500: 'customerGetLoansFailed_500'
};

export const createCustomerApiErrorMessages = {
    VALIDATE_ADDRESS_ERROR_500_POPUP: 'validate_address_error_500',
    SELECT_ADDRESS_ERROR_500_POPUP: 'select_address_error_500',
    CREATE_CUSTOMER_PAGE_CONTINUE_ERROR_500_POPUP: 'create_customer_continue_error_500',
    DELIVERY_AND_PAYMENT_PAGE_CONTINUE_ERROR_500_POPUP: 'delivery_and_payment_page_continue_error_500_popup'
};

export const cartRestErrorMassages = {
    SHARER_PLAN_MAXIMUM_MEMBERS_ALLOWED_EXCEEDED_409: 'Max_Limit_Exceeded',
    SHARER_PLAN_GENERAL_ERROR_MESSAGE_500: 'someSharerErrorCode',
    AdaptLineIncompatibleLevelPlan: 'adapt_line_incompatible_level_plan',
    AdaptLineMoreThanOneLevelPlan: 'adapt_Line_More_Than_One_Level_Plan',
    CART_GENERAL_ERROR_MESSAGE_500: 'someErrorCode_500',
    CANNOT_COMPLETE_PAYG_FOR_COLLECTION_409: 'Cannot_complete_for_Collection',
    CART_GENERAL_ERROR_500_POPUP: 'someError_popup_500',
    CART_GET_BY_ID_500_POPUP: 'cart_get_by_id_popup_500',
    MODIFY_PHONE_NUMBER_POP: 'modify_phone_number_pop_500',
    VALIDATE_PORT_IN_POP_INVALID_INPUT: 'validate_port_in_pop_500_400',
    REMOVE_ITEM_POPUP: 'remove_item_popup_500',
    SENT_EMAIL_POPUP: 'sent_email_popup_500',
    ASSOCIATE_EMAIL_POPUP: 'associate_email_popup_500',
    CART_GET_BY_ID_MINI_MESSAGE: 'cart_get_by_id_mini_message_500',
    CREATE_CART_POPUP_PLAN_SETTINGS: 'create_cart_popup_plan_settings_500',
    SUBMIT_ONE_OFF_PAYMENT_CHARGES: 'submit_one_off_payment_charges_500'
};

export const addonsErrorMessages = {
    SAVE_SPEND_CAP_ERROR: 'save_spend_cap_error_500',
    ADD_ADDON_ERROR: 'add_addon_error_500',
    ADD_INSURANCE_ERROR: 'add_insurance_error_500',
    REMOVE_ADDON_ERROR: 'remove_addon_error_500',
    ADD_ACCESSORIES_ERROR: 'add_accessories_error_500',
    REMOVE_ACCESSORIES_ERROR: 'remove_accessories_error_500'
};

export const isKeepYourNumberPageErrorMessages = {
    VERIFY_NUMBER_CHECK_CODE_POP_500: 'verify_number_check_code_pop_500',
    VALIDATE_PORT_IN_POP_500: 'validate_port_in_pop_500',
    VALIDATE_PORT_IN_POP_500_400_INVALID_INPUT: 'validate_port_in_pop_500_400'
};
export const tradeInErrorMessages = {
    GET_QUETIONS_FOR_TRADEIN_POP_500: 'get_questions_for_tradein_pop_500',
    GET_QUOTE_FOR_TRADEIN_POP_500: 'get_quote_for_tradein_pop_500',
};

export const isSelectPaymentPageErrorMessages = {
    CREDIT_CHECK_VETTING_POP_500: 'credit_check_vetting_pop_500',
    SUBMIT_ORDER_MS_POPUP: 'submit_order_ms_popup_500'
};
export const isSwitchResponseErrorMessage = {
    SWITCH_RESPONSE_ERROR_PAGE: 'switch_response_500'
};

export const contractSummaryErrorMessages = {
    SEND_EMAIL_ERROR: 'send_email_error_500',
    DOWNLOAD_PDF_ERROR: 'download_pdf_error_500',
    DOWNLOAD_CONTRACT_INFORMATION_ERROR: 'download_contract_information_error_500'
};

export const isOrderSummaryPageErrorMessages = {
    ORDER_GENERATE_CONTRACT_POP_500: 'order_generate_contract_pop_500',
    GET_ORDER_BY_ID_POPUP: 'get_order_by_id_popup_500',
    CANCEL_ORDER_POPUP: 'cancel_order_popup_500'
};

export const ERROR_PAGE_TRANSLATE = {
    MORE_DETAILS: 'errorPage.errorMoreDetails',
    ERROR_PAGE: 'errorPage.',
    ERROR_PAGE_TITLE: 'errorPageTitle',
    GLOBAL_AUTH_ERROR: 'errorPage.globalAuthError',
    GLOBAL_ERROR_CODE: 'globalErrorCode',
    NO_CUSTOMER_FOR_USER: 'NoCustomersForUser',
    AUTH_ZERO_LOGOUT_ERROR: 'errorPage.authZeroLogoutError',
    ERROR_UUID: 'err-erroruuid',
    ERROR_CODE: 'err-errorcode',
    ERROR_MESSAGE: 'err-errormessage',
    BACKEND_SOURCE: 'err-backendsource',
    BACKEND_ERROR_MESSAGE: 'err-backenderrormessage',
    BACKEND_MESSAGE: 'err-backendmessage',
    BACKEND_ERROR_CODE: 'err-backenderrorcode'
};

export const releaseCustomerErrorMessages = {
    CUSTOMER_RELEASE: 'customer_release_500',
    RETRIEVE_RELEASE_REASONS: 'retrieve_release_reasons_500'
};

export const associateCustomerErrorMessages = {
    COLLECTION_CUSTOMER: 'COLLECTION_CUSTOMER_500',
    CLOSED_OR_CANCELLED_BAN: 'CLOSED_OR_CANCELLED_BAN_500',
    AML_CUSTOMER: 'AML_CUSTOMER_500',
    FRAUD_CUSTOMER: 'FRAUD_CUSTOMER_500',
    GENERIC_ASSOCIATE: 'GENERIC_ASSOCIATE_500'
};

export const PENDING_ORDER_EXIST_ON_PRODUCT = 'PendingOrderExistsOnProduct';

export const URL_CONST = {
    HTTPPROTOCOL: 'http:',
    HTTPSPROTOCOL: 'https:',
    PORT: '35001',
};

export const SMARTWATCH_COMPATIBILITY_STATUS = {
    INFORMATION: 'information',
    BLOCKED: 'blocked',
    WARNING: 'warning'
};

export const HASHTAG_SIGN = '#';

export const NA = 'NA';
export const NOT_AVAILABLE = 'N/A';

export const AFFILIATE_CODE = 'Affiliate_Code';
export const AFFILIATE_CODE_VALUE = 'Affiliate_Code_Value';
export const IS_BUSINESS_CUSTOMER = 'isBusinessCustomer';

export const UPDATE_PROFILE_DATE_FIELD = 'birthDate';
export const UPDATE_PROFILE_EMAIL_FILED = 'EmailAddress';
export const UPDATE_PROFILE_CONTACT_FILED = 'ContactNumber';

export const Z_INDEX_FOR_MODAL = 99999;
export const Z_INDEX_FOR_POPPER = 999999;
export const SLASH = '/';
export const DELIMITER = '|';
export const NA_TEXT = 'NA';

export const ACCESSORY_BASKET_PACKAGE_MOBILE_ID = 'ACCESSORY_BASKET_PACKAGE_MOBILE_ID';

export const SYSTEM = '_system';

export const TABLE_VIEW = ' tablet-view';

export const LOAD_EXT_CONFIGURATION_EVENT = 'loadExternalConfigAmdxEvent';
export const LOAD_STORE_REQUEST = 'loadDigStoreRequest';
export const LOAD_STORE_SUCCESS = 'loadDigStoreSuccess';

export const BUSINESS_REGEX = /\/business/g;
export const PLANS_PAGE_REGEX = /\/plans/g;
export const RETAIL_REGEX = /\/retail/g;
export const PATH_NAME = 'pathname';
export const CALL_CENTER = 'CALL_CENTER';
export const CONSUMER_MOBILE_APP = 'CONSUMER_MOBILE_APP';

export const EVENT_POSTMESSAGE = 'message';

export const DEBUG_LOGS = 'DEBUG_LOGS';

export const SET_FALSE = false;

export const ADDONS_URL_FOR_DEFAULT_IMAGES = '/content/dam/digitalexp/commerce/catalog/add_ons/ADDON_GENERICTHREE.png';

export const ADD = 'add';
export const REPLACE = 'replace';
export const DELETE = 'delete';
export const MODIFY = 'modify';

export const THREE_UK_LOGIN_LINK = '/customer-login?orgID=null&msisdn=null&B2BFlag=false';

export const BUSINESS_BROADBAND_LINK = 'https://www.three.co.uk/business/broadband';

export const ANONYMOUS = 'anonymous';
export const SCRIPT_TAG_NAME = 'script';
export const EMPTY = 0;

export const SMARTWATCHFLOW = 'SW';

export const KEEP_YOUR_NUMBER = 'KEEP_YOUR_NUMBER';

export const flowPages = {
    CUSTOMER_360_PAGE: 'CUSTOMER_360_PAGE',
    RELEASE_CUSTOMER: 'RELEASE_CUSTOMER'
};

export const YES = 'Yes';
export const NO = 'No';
export const ELIGIBILITY_TYPES = {
    SUSPENDED: 'SUSPENDED',
    PENDING_ORDER: 'PENDING_ORDER',
    CUSTOMER_IN_COLLECTION: 'CUSTOMER_IN_COLLECTION',
    ELIGIBILITY: 'ELIGIBILITY',
    NONE: 'NONE'
};
export const NOT_FOUND = -1;
export const ActivateSIMPageConstants = {
    NO_ORDER: 'NO_ORDER',
    SUCCESS: 'SUCCESS',
    FORM_NAME: 'ActivateSimForm',
    SIM_SWAP_EXIST: 'SIM_SWAP_EXIST',
    UPGRADE_EXIST: 'UPGRADE_EXIST',
    ESIM_EXIST: 'ESIM_EXIST',
    ESIM_INFO_NOT_AVALIABLE: 'ESIM_INFO_NOT_AVALIABLE',
    ERROR: 'ERROR',
    REASON_CODE: 'RSND',
    LINE_SUCCESS: 'LINE_SUCCESS',
    COMPLETE_SUCCESS: 'COMPLETE_SUCCESS',
    SUBSCRIPTION_STATUS: 'Active',
    ESIM_SIM: 'eSIM',
    SEAMLESS_TRANSFER: 'Seamless Transfer',
    ACTIVATE_SIM_FAILED_500: 'activate_sim_failed_500'
};
export const BILL = 'Bill';
export const CARD = 'Card';

export const UPDATED_EUF_AMOUNT_FORM_FIELD = 'updateEUFAmount';
export const EUF_PAYMNET_OPTION_FORM_FIELD = 'eufPaymentOption';

export const ERROR_TIMEOUT_MESSAGE = 'Service call timed out. Please try again later.';
export const ERROR_001 = 'ERR_001';
export const TIME_OUT = 'timed out';
export const ERR_BACKEND_MESSAGE = 'ERR-backendErrorMessage';

export const OVERRIDE_EUF_FORM = 'overrideEUFForm';
export const BY_BILL = 'Add to bill';
export const LOWER_THEN_199 = 199;
export const GRATER_THEN_300 = 300;

export const FUNCTIONALITY_MANAGEMENT = 'FUNCTIONALITY_MANAGEMENT';
export const PAYPAL_CLIENT_IDS = 'PAYPAL_CLIENT_IDS';

export const DEVICE_PRICING_TYPE = 'DEVICE_PRICING_TYPE';
export const TRICOLOR = 'Tricolor';

export const SEPARATOR = ', ';
export const FEATURE = 'Feature';

export const NEGATIVE_FOUR = -4;

export const OVER_ALL_MONTHLY_COST = 'Overall monthly cost';

export const TOTAL_OTHER_MONTHLY_COST = 'Total other monthly costs';

export const SMOOTH = 'smooth';
export const SCROLL_SMOOTH_DURATION = 250;
export const SCROLL_BLOCK_OPTIONS = {
    START: 'start',
    CENTER: 'center',
    END: 'end',
    NEAREST: 'nearest',
};
export const NAVIGATE_TO_VAT_LINK_ID = 'navigateToVatLink';
export const PLAN_API_SORT_PARAMS = {
    TOP_ITEM: 'topItem',
    PRICE: 'price'
};

export const REGULAR = 'regular';
export const ADVANCE = 'advance';
export const DEVICE_SUPPORT = 'https://devicesupport.three.co.uk/';
export const CONTACT_US = 'https://three.co.uk/contact-us';

export const DESCRIPTIVE_CHAR_BY_NAME = {
    DATA: 'Data',
    MINUTES: 'Minutes',
    TEXTS: 'Texts'
};
export const ROUTE_INDICATORS = {
    PHONES_GALLERY: '/phones',
    TABLETS_GALLERY: '/tablets',
    SMART_WATCHES_GALLERY: '/smart-watches',
    SIM_ONLY_PAY_MONTHLY_GALLERY: '/sim-only/pay-monthly',
    SIM_ONLY_PAY_AS_YOU_GO_GALLERY: 'sim-only/pay-as-you-go',
    HOME_BROADBAND_GALLERY: '/broadband/home-broadband',
    MOBILE_BROADBAND_GALLERY: '/broadband/mobile-broadband',
    BROADBAND_COVERAGE_CHECKER: '/broadband/coverage-checker',
    BROADBAND_DATA_SIM_PAY_MONTHLY: '/broadband/data-sim-pay-monthly',
    BROADBAND_DATA_SIM_PAY_AS_YOU_GO: '/broadband/data-sim-pay-as-you-go',
};

export const HTTPS = 'https://';
export const CPE = 'CPE';
export const DEVICE_TYPE = 'Device Type';
export const UNDEFINED = undefined;
export const UNKNOWN_STRING = 'unknown';

export const SIM_NUMBER_DEFAULT_DIGITS = '89442';

export const SUCCESS_RESPONSE_STRING = 'Success';

export const DEEP_LINK_FLOW = 'DEEP_LINK_FLOW';

export const MANAGE_PDF = {
    PDF_TYPE: 'Data',
    PDF_ACTION: 'Print document'
};

export const addcomments = 'Add comments';
export const MISSING_TRANSLATION = 'Missing translationId:';
export const BUFFER_TIME_FOR_MODAL_AND_APIS = NUMBER_ONE_AND_A_HALF * secondInMilliseconds * minuteInSeconds;
export const BUFFER_TIME_FOR_MODAL_AND_APIS_TWO_MINUTES = NUMBER_TWO * secondInMilliseconds * minuteInSeconds;

export const USE_BACK = {
    PUSH: 'PUSH',
    POP: 'POP'
};

export const CR148_MOBILE = 'CR148_MOBILE';

export const EXTRA_CATEGORIES = {
    ADDONS: 'addons'
};

export const COMPONENT_BUSINESS_TYPE = {
    DP: 'DP'
};

export const FEATURE_FLAG_TOGGLE = {
    ON: 'ON',
    OFF: 'OFF',
    BOTH: 'BOTH'
};

export const APP_AND_FLOW_TYPE = {
    COP_RESUME_ORDER: 'COP_ResumeOrder',
    RESUME_ORDER: 'ResumeOrder',
    RETAIL: 'RETAIL',
    SELF_SERVICE: 'SELF_SERVICE',
    COP: 'COP',
    MOBILE_APP: 'MOBILE_APP'
};

export const GENERAL_FLOW_TYPES = {
    ANONYMOUS: 'ANONYMOUS',
    PREPAID: 'PREPAID',
    POSTPAID: 'POSPAID',
    UPGRADE: 'UPGRADE',
    CHANGE_PLAN: 'CHANGE_PLAN',
    RESUME_ORDER: 'RESUME_ORDER',
    AFFILIATE: 'AFFILIATE'
};

export const COMBINATION_FLOWS_CONSTANTS = {
    AFFILIATE_PREPAID: 'AFFILIATE_PREPAID',
    AFFILIATE_POSTPAID: 'AFFILIATE_POSTPAID'
};
export const permissionCheckboxesNames = {
    CORE_SMS_MMS: 'CORE_SMS_MMS',
    CORE_EMAIL: 'CORE_EMAIL',
    CORE_PHONE: 'CORE_PHONE',
    CORE_DM: 'CORE_DM',
    CORE_APP: 'CORE_APP',
    PARTNERSHIP_OFFERS: 'PARTNERSHIP_OFFERS',
    LOCATION: 'LOCATION',
    PROFILING_AND_TARGETED_ADS: 'PROFILING_AND_TARGETED_ADS',
    SURVEY_CONSENT: 'SURVEY_CONSENT'
};
export const selfService = 'selfService';

export const SWITCH_RESPONSE_ERR = 'SWITCH_RESPONSE_ERR';

export const TOP_UP = 'topUp';

export const PAYMENT_CARD_INTERACTION = {
    CHANGE: 'change',
};

export const ACCEPTED = 'Accepted';
export const DATA_SIM_PAY_AS_YOU_GO = 'data-sim-pay-as-you-go';
export const PAY_AS_YOU_GO = 'pay-as-you-go';
export const TREE_LINK = 'https://www.three.co.uk/';
export const INSTALLATION_ADDRESS = '/installationAddress';

export enum Channels {
    SELF_SERVICE = 'SELF_SERVICE',
    RETAIL = 'RETAIL',
    MOBILE_APP = 'MOBILE_APP'
}
export enum ChannelsCode {
    SELF_SERVICE = 'S',
    RETAIL = 'R',
    MOBILE_APP = 'CM'
}
export const ONE_DAY_IN_MILLISECONDS = NUMBER_TWENTY_FOUR * minuteInSeconds * minuteInSeconds * secondInMilliseconds;
export enum componentTypeEnum {
    ERROR = 'ERROR',
    INITIAL = 'INITIAL'
}
export enum SESSION_STORAGE_KEYS_TO_REMOVE {
    ORDER_PERSISTOR = 'persist:orderPersistor',
    CART_PERSOSTOR = 'persist:cartPersistor',
    DATA_LAYER_PERSISTOR = 'persist:dataLayer',
    DIGITAL_DATA_PERSISTOR = 'persist:dataLayer',
    USER = 'persist:user',
    ORDER_CONFRIMATION_PAGE_PERISISTOR = 'persist:orderConfirmationPagePersist'
}
export enum EVENT_LISTENER_NAME {
    BEFORE_UNLOAD = 'beforeunload',
    POP_STATE = 'popstate'
}

export const EVENT_VISIBILITY_CHANGE = 'visibilitychange';
export const EVENT_VISIBLE = 'visible';
export const PRE_PAID = 'pre';
export const POST_PAID = 'post';

export enum REST_API_ERROR_HANDLER {
    BILL_HISTORY_FAILED_500 = 'billHistoryFailed_500',
    GET_PRODUCT_BY_CUSTOMER_ID_FAILED_500 = 'getProductsByCustomerIdFailed_500'
}
export const RADIUS = 'RADIUS';
export const RADIUS_DEFAULT = 'RADIUS_DEFAULT';
export const MAXIMUM_STORES_PICKUP = 'MAXIMUM_STORES_PICKUP';
export const STORE_FORM = 'search-store-form';
export const SEMICOLON = ';';
export const DEFAULT_MSISDN_VALUE = 'DEFAULT_MSISDN';
export const DATA = 'Data';
export const DATA_PACK = 'Data Pack';
export const NULL = 'null';
export const NULL_TYPE = null;

export enum productCharacteristicNames {
    SpendAlertDefaultAmount = 'SpendAlertDefaultAmount'
}

export const AdaptLineIncompatibleLevelPlan = 'AdaptLineIncompatibleLevelPlan';
export const AdaptLineMoreThanOneLevelPlan = 'AdaptLineMoreThanOneLevelPlan';

export const TESTING_ENDPOINTS_RGX = /^((https?:\/\/)?(inlnqw|uknpmps|localhost))/;
export const CART_REMOVE_MESSAGE = {
    REMOVE_CART_FAILED_500: 'Only whole order can be cancelled post reservation! Please cancel the order.'
};

export const DEVICE = 'Device';
export const PLAN = 'Plan';
export const STRING = 'string';

export const ADDONS_USAGE_TYPE_IDS = {
    DATA: '8489079',
    ROAMING: '8927689',
    INSURANCE: '8488989',
    INTERNATIONAL: '8489019',
    DATA_PACK: '590687'
};

export const GENERAL_ERROR = 'generalError';

export const VULNERABLE_CUSTOMER = 'Authorised contact request';

export const UNLIMITED = 'unlimited';

export const VALUE = 'value';

export const REGEX_FOR_UNIT = /[a-zA-Z][a-zA-Z]/g;

export const REGEX_FOR_DIGITS = /(\d+)/g;

export const GB = 'gb';

export const GB_TO_MB_MULTIPLIER = 1024;
export const MINUS_THREE = -3;
export const COMMITMENT_DURATION = 'Commitment Duration';
export const PLAN_TYPE = 'Plan Type';

export enum MEDIA_BREAKPOINTS {
    lessThan = 'lessThan',
    greaterThanOrEqual = 'greaterThanOrEqual'
}

export const MAINTAINABLE_STORAGE_ITEMS = [
    'B2BsessionActive', 'B2CsessionActive', 'CXUI_closed', 'CXUI_min', 'CXUI_pending', 'CXUI_agentId', 'CXUI_agentName',
    'CXUI_convId', 'CXUI_MedalliaDone', 'kampyleInvitePresented', 'CXUI_disconnect', 'com.adobe.reactor.dataElements.OnetrustActiveGroups'
];
export const MAINTAINABLE_STORAGE_ITEMS_NAME_INCLUDE = {
    BOLD_CHAT_SESSION_ID: ':gcmcsessionActive',
};
export const TOAST_CONSTANT = {
    success: 'success',
    topCenter: 'top-center',
    colored: 'colored'
};

export const OWN = 'own';

export enum TRADE_IN_STEPS {
    STEP_1 = 'findDevice',
    STEP_2 = 'checklist',
    STEP_3 = 'yourQuote'
}

export const COLOR = 'color';
export const STORAGE = 'storage';

export const TRADE_IN_FORM_NAME = 'tradeInImei';

export enum TRADE_IN_SET_SETTLEMENT_OPTION {
    BANK_TRANSFER = 'BANK_TRANSFER',
    NEW_LOAN = 'NEW_LOAN',
    STORE_CREDIT = 'STORE_CREDIT',
    EXISTING_LOAN = 'EXISTING_LOAN'
}

export const TRADE_IN_STORE_CHECKBOX_ID = 'tradeInStoreCheckbox';

export const PURCHASE_AS_INSTALLMENTS = 'INSTALLMENTS';

export enum AddonsComponentTypeLocation {
    reviewBasket = 'reviewBasket',
    miniCart = 'miniCart',
    basketPackage = 'basketPackage',
}

export const containerTypes = {
    TRADE_IN_PRICE_HEADER: 'tradeInPriceHeader',
    PAY_TODAY: 'payToday',
    MONTHLY_COST: 'monthlyCost'
};

export const tradeInStatus = {
    ACCEPTED: 'ACCEPTED',
    CANCELLED: 'CANCELLED',
};

export const discountStatus = {
    ADDED: 'Added',
    AVAILABLE: 'Available',
};

export const TRADE_IN_PROMO_CODE = 'Trade_In_Promo_code';
export const REVIEW_BASKET = 'REVIEW_BASKET';
export const DEVICE_DETAILS = 'DEVICE_DETAILS';
export const NULL_LATITUDE_LONGITUDE = 'ExperianEnrichmentNullLatitudeLongitude';

export const DATA_PACK_TYPE = 'DP';
export const MOBILE_STRING = 'mobile';

export const AMDOCS_DIGITAL_SUFFIX = 'A';

export const TRADE_DEVICE = 'DEVICE';
export const UPGRADE_SIM_ONLY = 'Mobile_SIM_Only';
export const NO_RECORDS = 'NoRecords';
export const PageWrapperClassName = {
    RETAIL_WRAPPER_CLASS_NAME: 'retail-dashboard-wrapper',
};

export const MAX_SUB_LENGTH_CUSTOMER_DASHBOARD = 5;
export const CAMPAIGN_OFFER_ID = 'CampaignOfferId';
export const BROADBAND = 'Broadband';
export const BROADBAND_DEVICES = 'Broadband Devices';
export const HOME_DEVICES = 'Home Devices';
export const SIMO_PAYG_REDIRECTION_LINK = 'SIMO_PAYG_REDIRECTION_LINK';
export const DATA_SIMO_PAYG_REDIRECTION_LINK = 'DATA_SIMO_PAYG_REDIRECTION_LINK';
export const PHONES = 'Phones';

export const TRADE_IN_SIMO = 'SIMO';
export const TRADE_IN_TAB = 'Tab';

export const RETURN_MODE = 'returnMode';
export const UNDEFINED_TEXT = 'undefined';

export const AutomationId = {
    DEVICE_DETAILS_PAY_ALL_TODAY: 'device-details-pay-all-today',
    PERFORM_CREDIT_CHECK_CONTINUE_BUTTON: 'perform-credit-check-continue-button',
    ORDERֹֹֹ_SUMMARY_SUBMIT_BUTTON: 'order-summary-submit-button',
    ORDER_SUMMARY_CANCEL_BUTTON: 'order-summary-cancel-button',
    PLANS_PAGE_CONTINUE_BUTTON: 'plans-page-continue-button',
    DELIVERY_METHOD_PAGE_CONTINUE_BUTTON: 'delivery-method-page-continue-button',
    ADDONS_PAGE_CONTINUE_BUTTON: 'addons-page-continue-button',
    CREATE_CUSTOMER_CONTINUE_BUTTON: 'create-customer-page-continue-button',
    DELIVERY_PAGE_CV_MODAL_CONFIRM_DETAILS_PROVIDED_CORRECT: 'delivery-page-cv-modal-confirm-details-provided-correct',
    DELIVERY_PAGE_PAYMENT_SECTION_CONFIRM_DETAILS_PROVIDED_CORRECT: 'delivery-page-payment-section-confirm-details-provided-correct'
};
export const USAGE_TYPE_STRING = 'roam_pass';
export const EXPIRATION_DATE_FOR_USAGE_TYPE = '2222-01-01';
export const GROUP_OPTION_ID = '8927689';
export const USAGE_TYPE_TITLE = 'Roaming';
export const ESCAPE_KEY_STRING = 'Escape';

export const storeAddressConstant = {
    STORE_PICKUP_SEARCH_STORE_SECTION: 'storePickUpSearchStoreSection',
    ADDRESS: 'address',
    SEARCH_STORE_FORM: 'search-store-form',
    EXCLUDE_OUT_OF_STOCK: 'excludeOutOfStock'
};

export const REGEX_FOR_PERCENTAGE = /(\d+)%/;
export const PAY_BILL = 'payBill';
export const BUY_SHOP = 'buyShop';

export const SCREEN_TYPES = {
    DESKTOP: 'desktop',
    MOBILE: 'mobile',
    TABLET: 'tablet',
};

export enum PRICE_TYPE {
    monthly = 'monthly',
    now = 'now',
}

export const THREE_BUSINESS = 'THREE_BUSINESS';

export const INSURANCE_NAME = 'INSURANCE_NAME';

export const TOP_PROVIDERS = 'TOP_PROVIDERS';

export const LOCALE = 'en_GB';
export const HIDE_B2B_STEP_LIST = 'HIDE_B2B_STEP_LIST';
export const PRICE = 'price';

export const REQUIRED = 'required';
export const FIELD = 'Field';

export const MARGIN_THIRTY = 'margin-thirty';

export enum ACTION_LIFECYCLE {
    NOT_ACTIVE = 'notActive',
    ON_START = 'start',
    IN_PROGRESS = 'inProgress',
    DONE = 'complete',
}
export interface ActionLifecycle {
    [key: string]: ACTION_LIFECYCLE;
}
export const FIVE_AM = 5;
export const TWELVE_PM = 12;
export const SIX_PM = 18;
export const TWELVE_AM = 12;
export const PAY_AS_YOU_GO_SUPPORT_LINK = 'https://www.three.co.uk/support/pay-as-you-go';
export const PAYM_NEED_HELP_LINK = 'https://www.three.co.uk/support/bills-and-contracts';
export const PAYM_NEED_HELP_WITH_FIRST_BILL_LINK = 'https://www.three.co.uk/support/bills-and-contracts/understanding-your-bill/about-your-first-bill';
export const PAYM_NEED_HELP_WITH_YOUR_BILL_LINK = 'https://www.three.co.uk/support/bills-and-contracts';

export enum ALERT_TYPES {
    INFO = 'info',
    SUCCESS = 'success',
    ERROR = 'error'
}
export const B2B_OFFER_PAGE = 'B2B_OFFER_PAGE';

export const WIN_OS = 'Windows';
export const MAC_OS = 'Mac OS';
export const TEN_PENCE = '0.1';

export enum appleGoogleOnOff {
    SS = 'SS',
    APP = 'APP'
}

export const planCardsClassNames = ['plans-card-root', 'plans-card-wrapper'];
export const COOKIES_REGEX = '=([^;]+)';
export const TARGET_COOKIES = 'targetGlobalControl';
export const PRODUCTION = 'PRODUCTION';
export const STAGING = 'STAGING';
export const SIMULATOR_ALL = 'simulator_all';

export enum CUSTOMER_TYPE_CONVERSION {
    O = 'Active',
    S = 'Suspended',
    N = 'Cancelled',
    T = 'Tentative'
}

export const ANONYMOUS_TOPUP_LINK = 'https://www.three.co.uk/shop/anonymous-topup';

export const SHOP_LINK = 'https://www.three.co.uk/shop';

export const ADD_ADDONS_JOURNEY_NAME = 'PayGAddOns';
export const TWO_D = '2d';

export const AGENTS = {
    WEBSITE: 'web',
    MOBILE: 'mobile',
    TABLET: 'tablet'
};

export const PARAMS_TYPES = {
    STRING: 'string',
    NUMBER: 'number',
    BOOLEAN: 'boolean',
    DATE: 'date',
    ARRAY: 'array'
}
