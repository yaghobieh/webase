export enum CreateCustomerConstant {
	SOLE_TRADER = 'Sole Trader',
	PARTNERSHIP = 'Partnership',
	LIMITED = 'Limited',
	CHARITY = 'Charity',
	PUBLIC_SECTOR = 'Public Sector',
	CONSUMER = 'Consumer',
	INDIVIDUAL = 'individual',
	BUSINESS = 'business',

	BUSINESS_DETAILS_ADDRESS_SECTION_NAME = 'BusinessDetailsAddressSectionName',
	BILLING_DETAILS_ADDRESS_SECTION_NAME = 'BillingDetailsAddressSectionName',
	HOME_DETAILS_ADDRESS_SECTION_NAME = 'HomeDetailsAddressSectionName',
	PREVIOUS_HOME_DETAILS_ADDRESS_SECTION_NAME = 'PreviousHomeDetailsAddressSectionName',
	PREVIOUS_ADDRESS_START_DATE_FIELD_NAME = 'previousAddressStartDate',
	PREVIOUS_ADDRESS = 'previousAddress',
	EMPLOYMENT_START_DATE = 'EmploymentStartDate',
	ADDRESS_START_DATE = 'addressStartDate',
	BANK_ACCOUNT_SINCE = 'bankAccountSince',
	BUSINESS_DETAILS_SECTION_NAME = 'BusinessDetailsSectionName',
	YOUR_DETAILS_SECTION_NAME = 'YourDetailsSectionName',
	ID_DOCUMENTS_SECTION_NAME = 'IDDocumentsSectionName',
	EMPLOYMENT_DETAILS_SECTION_NAME = 'EmploymentDetailsSectionName',
	BANK_DETAILS_SECTION_NAME = 'BankDetailsSectionName',
	ADDRESS_DETAILS_SECTION_NAME = 'AddressDetailsSectionName',
	BUSINESS_COMPANY_DETAIL = 'businessCompanyDetail',
	PREVIOUS_ADDRESS_FORMAT = 'previousAddressFormat',
	CREATE_CUSTOMER_FORM_NAME = 'createCustomerForm',
	INDUSTRY_TYPE = 'industryType',
	EMAIL_ADDRESS = 'emailAddress',

	DAY = 'day',
	MONTH = 'month',
	YEAR = 'year',

	NUMBER_OF_EMPLOYEES_MIN_RANGE = '0',
	NUMBER_OF_EMPLOYEES_MAX_RANGE = '100',

	EMPLOYMENT_CATEGORY = 'employmentCategory',
	EMPLOYMENT_STATUS = 'employmentStatus',
	PRIVACY_POLICY_LINK = 'https://www.three.co.uk/your_privacy',

	KEY_TO_FIND = 'op',
	DUPLICATED_EMAIL = 'DUPLICATED_EMAIL',
	BUSINESS_COMPANY_REG_NUMBER = 'businessCompanyRegNumber',
	IS_SELECTED_COMPANY_DETAILS = 'IS_SELECTED_COMPANY_DETAILS',
	IS_COMPANY_DETAIL_NOT_SELECTED = 'IS_COMPANY_DETAIL_NOT_SELECTED'
}

export const BUSINESS_LIMITED_ARRAY = [CreateCustomerConstant.LIMITED, CreateCustomerConstant.CHARITY, CreateCustomerConstant.PUBLIC_SECTOR];

export enum EmploymentOptions {
	UNEMPLOYED = 'Unemployed',
	HOUSEWIFE = 'House Person',
	STUDENT = 'Student',
}

export const CustomerTypesIDS = {
	individual: 'IND',
	employee: 'EMP',
	soho: 'SOH',
	micro: 'MIC',
	small: 'SMA',
	prepaid: 'PPD',
};

export const CustomerTypesValues = {
	IND: 'Individual',
	EMP: 'Employee',
	SOH: 'SOHO',
	MIC: 'Micro',
	SMA: 'Small',
	PPD: 'Prepaid',
};

export const CreateCustomerValidationConstant = {
	YEAR_BOTTOM_RANGE: 1900,
	DAY_MIN_RANGE: 1,
	DAY_MAX_RANGE: 31,
	MONTH_MIN_RANGE: 1,
	MONTH_MAX_RANGE: 12,
};

export const EmploymentCategoryId = {
	UNEMPLOYED: 'U'
};

export const UpdateProfileConstant = {
	UPDATE_HOME_ADDRESS_FORM: 'updateHomeAddressForm',
	UPDATE_BILLING_ADDRESS_FORM: 'updateBillingAddressForm',
};

export const VIEW_PERSONAL_DETAILS_FROM = 'ViewPersonalDetailsForm';

export const AddressFormat = {
	UK_ADDRESS: 'UK',
	BRITISH_FORCES_ADDRESS: 'BF',
	FOREIGN_ADDRESS: 'OV',
};
export const ADDRESS_LINE_1_MAX_LENGTH = 200;
export const ADDRESS_LINE_2_MAX_LENGTH = 200;
export const ADDRESS_LINE_3_MAX_LENGTH = 200;
export const CITY_MAX_LENGTH = 40;
export const POSTAL_CODE_MAX_LENGTH = 20;
export const BFPO_ID_LENGTH = 8;
export const IS_REPLACE_CONTACT = 'IS_REPLACE_CONTACT';
export const IS_NOT_REPLACE_CONTACT = 'IS_NOT_REPLACE_CONTACT';
export const IS_PARTNERSHIP_OR_SOLO_TRADER = 'IS_PARTNERSHIP_OR_SOLO_TRADER';
export const IS_NOT_PARTNERSHIP_OR_SOLO_TRADER = 'IS_NOT_PARTNERSHIP_OR_SOLO_TRADER';
export const IS_LIMITED_OR_CHARITY_OR_PUBLIC_SECTOR = 'IS_LIMITED_OR_CHARITY_OR_PUBLIC_SECTOR';
export const IS_BUSINESS = 'IS_NOT_PARTNERSHIP_OR_SOLO_TRADER';
export const IS_NOT_BUSINESS = 'IS_NOT_PARTNERSHIP_OR_SOLO_TRADER';
export const BILL_PAY = 'BILL_PAY';
export const PREPAY = 'PREPAY';
export const POSTPAY = 'POSTPAY';
export const IS_ANONYMOUS = 'IS_ANONYMOUS';
export const IS_NOT_ANONYMOUS = 'IS_NOT_ANONYMOUS';
export const IS_NOT_PART_OF_OTS = 'IS_NOT_PART_OF_OTS';
export const IS_PART_OF_OTS = 'IS_PART_OF_OTS';
export const IS_BUSINESS_TYPE = 'IS_BUSINESS_TYPE';
export const IS_NOT_BUSINESS_TYPE = 'IS_NOT_BUSINESS_TYPE';
export const SHOW_EMPLOYMENT_DATE = 'SHOW_EMPLOYMENT_DATE';
export const DONT_SHOW_EMPLOYMENT_DATE = 'DONT_SHOW_EMPLOYMENT_DATE';
export const IS_SHOW_BUSINESS_ADDRESS = 'IS_SHOW_BUSINESS_ADDRESS';
export const IS_NOT_SHOW_BUSINESS_ADDRESS = 'IS_NOT_SHOW_BUSINESS_ADDRESS';
export const IS_SHOW_BILLING_ADDRESS = 'IS_SHOW_BILLING_ADDRESS';
export const IS_NOT_SHOW_BILLING_ADDRESS = 'IS_NOT_SHOW_BILLING_ADDRESS';
export const IS_BUSINESS_FLOW = 'IS_BUSINESS_FLOW';
export const IS_NOT_BUSINESS_FLOW = 'IS_NOT_BUSINESS_FLOW';
export const IS_BUSINESS_FLOW_SS_ANONYMOUS = 'IS_BUSINESS_FLOW_SS_ANONYMOUS';

export const SECTION_CONTAINS_DUPLICATE_FIELDS: string[] = [
	CreateCustomerConstant.ADDRESS_START_DATE,
	CreateCustomerConstant.HOME_DETAILS_ADDRESS_SECTION_NAME,
	CreateCustomerConstant.BILLING_DETAILS_ADDRESS_SECTION_NAME,
	CreateCustomerConstant.BUSINESS_DETAILS_ADDRESS_SECTION_NAME
];

export enum PreventMixingTypes {
	PRE_TO_BILL = 'PrepaidToBillpay',
	BILL_TO_PRE = 'BillpayToPrepaid'
}

export const SINGLE_MARITAL_STATUS = 'S';

export enum Path {
	BIRTHDAY = '/owningIndividual/birthDate',
	FIRSTNAME = '/owningIndividual/firstName',
	LASTNAME = '/owningIndividual/lastName',
	EMAIL = '/owningIndividual/contactMedium/0/emailAddress',
	BILLING_ADDRESS_STATE = '/billingAddress/stateOrProvince',
	BUSINESS_ADDRESS_STATE = '/businessAddress/stateOrProvince',
	SHIPPING_ADDRESS_STATE = 'stateOrProvince'
}
export const OWNING_INDIVIDUAL_CONTACT_MEDIUM_PATH = '/owningIndividual/contactMedium';
export const OWNING_INDIVIDUAL_ID_PATH = '/id';
export const OWNING_INDIVIDUAL_PREFERRED_PATH = 'preferred';

export const BFPO = 'BFPO';

export const addressValues = {
	FLOOR: 'floor',
	CITY: 'city',
	FORMATTED_ADDRESS: 'formattedAddress',
	FORMATTED_ADDRESS1: 'formattedAddress1',
	FORMATTED_ADDRESS2: 'formattedAddress2',
	FORMATTED_ADDRESS3: 'formattedAddress3',
	POSTAL_CODE: 'postalCode',
	DISTRICT: 'district',
	APARTMENT_NUMBER: 'apartmentNumber',
	STREET_FULL_NAME: 'streetFullName',
	BUILDING_NUMBER: 'buildingNumber',
	BUILDING_NAME: 'buildingName'
};

export enum BUSINESS_ADDRESS_PATHS {
	ID = '/businessAddress/id',
	FORMATTEDADDRESS = '/businessAddress/formattedAddress',
	FORMATTEDADDRESS1 = '/businessAddress/formattedAddress1',
	FORMATTEDADDRESS2 = '/businessAddress/formattedAddress2',
	FORMATTEDADDRESS3 = '/businessAddress/formattedAddress3',
	POSTALCODE = '/businessAddress/postalCode',
	CITY = '/businessAddress/city',
	BUILDING_NUMBER = '/businessAddress/buildingNumber',
	ADDRESS_STATUS = '/businessAddress/addressStatus',
	STREET_FULL_NAME = '/businessAddress/streetFullName',
	COUNTRY = '/businessAddress/country',
	STATE = '/businessAddress/stateOrProvince',
	APARTMENT_NUMBER = '/businessAddress/apartmentNumber',
	BUILDING_NAME = '/businessAddress/buildingName',
	STREET = '/businessAddress/street'
}

export enum ADDRESS_SINCE {
	MONTH = 'addressSinceMonth',
	YEAR = 'addressSinceYear'
}

export const ALLOW_ALL_UPDATES = 'allowAllUpdates';

export const createCustomerFiledsIDS = {
	FIRST_NAME: 'firstName',
	LAST_NAME: 'lastName',
	RESIDENCE_STATUS: 'residenceStatus',
	MARITAL_STATUS: 'maritalStatus',
	PHONE_NUMBER: 'phoneNumber',
	EMAIL_ADDRESS: 'emailAddress',
	CONFIRM_EMAIL: 'confirmEmail',
	EMPLOYMENT_CATEGORY: 'employmentCategory',
	DOB: 'dateOfBirth',
	TITLE: 'Title',
};

export const employmentTypeOrder = [
	'Self Employed Professional',
	'Self Employed Non Professional',
	'Employed',
	'Part Time Employed',
	'Temporary Employment',
	'Student',
	'Homemaker',
	'Retired',
	'Unemployed',
	'Other',
	'Not Applicable'
];

export const UNEMPLOYED_EMPLOYMENT_TYPE = 'Unemployed';

export const CREATE_CUSTOMER_AUTOMATIONS_IDS = {
	residenceStatus: 'ResidentialStatus',
	maritalStatus: 'MaritalStatus',
	employmentCategory: 'employmentType'
};

export const SECTION_CONTAINS_DATES_FIELDS: string[] = [
	createCustomerFiledsIDS.DOB,
	CreateCustomerConstant.BANK_ACCOUNT_SINCE,
	CreateCustomerConstant.EMPLOYMENT_START_DATE
];

export const CREATE_CUSTOMER_IDS_TO_INJECT = {
	'YourDetailsSectionName.firstName': createCustomerFiledsIDS.FIRST_NAME,
	'YourDetailsSectionName.lastName': createCustomerFiledsIDS.LAST_NAME,
	'YourDetailsSectionName.dateOfBirth.day': createCustomerFiledsIDS.DOB,
	'YourDetailsSectionName.dateOfBirth.month': createCustomerFiledsIDS.DOB,
	'YourDetailsSectionName.dateOfBirth.year': createCustomerFiledsIDS.DOB,
	'YourDetailsSectionName.phoneNumber': createCustomerFiledsIDS.PHONE_NUMBER,
	'YourDetailsSectionName.emailAddress': createCustomerFiledsIDS.EMAIL_ADDRESS,
	'YourDetailsSectionName.confirmEmail': createCustomerFiledsIDS.CONFIRM_EMAIL,
};

export const CREATE_CUSTOMER_ALLOWED_UPDATE_FIELDS_PATHS = [
	'/owningIndividual/firstName',
	'/owningIndividual/lastName',
	'/owningIndividual/birthDate',
	'/owningIndividual/contactMedium/0/emailAddress',
];

export const businessCompanyModal = {
	CANCEL: 'cancel',
	DONE: 'done'
};

export const BUSINESS_STATUS_DISABLED = 'D';
export const FATAL_OR_VALIDATION_ERROR = {
	fatalMessage: 'Sorry, something went wrong. Please try again.',
	noResultFoundMsg: 'We couldn’t find this company number. Please check and re-enter.',
	requiredErrorMessage: 'Please enter your registered number.'
};

export const NOT_APPLICABLE = 'Not Applicable';

export const ADDRESS_CHECKER_ARIM_CONSTANTS = {
	RETAIL_ADDRESS_CHECK: 'RETAIL_ADDRESS_CHECK',
	INVALID_POSTCODE: 'INVALID_POSTCODE'
};

export const otherEmploymentTypeId = 'X';
