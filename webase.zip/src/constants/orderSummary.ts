export const ORDER_SUMMARY_FORM_NAME = 'OrderSummaryForm';
export const NETWORK_IND = 'NetworkIND';
export const SIM_CARD_NUMBER = 'simCardNumber';
export const IMEI = 'IMEI';
export const MOBILE_DEVICE_PRODUCT = 'mobileDeviceProduct';
export const MOBILE_SIM_PRODUCT = 'mobileSimProduct';
export const SECTION_FORM_NAME_PREFIX = 'orderItemID_';
export const GENERATE_CONTRACT_ERROR_MESSAGE = 'generateContractFailed_500';
export const DEVICE_RESERVATION_ERROR_MESSAGE = 'deviceReservationFailed_500';
export const SIM_NUMBER_ALREADY_IN_USE_ERROR_MESSAGE = 'SimNumberAlreadyInUse_500';
export const INCONSISTENT_PARAMETERS = 'InconsistentParameters_500';
export const INCONSISTENT_PARAMETERS_ERROR_OCCURRED = 'InconsistentParametersErrorOccurred_500';
export const PREPAID_INSUFFICIENT_BALANCE_ERROR = 'PrepaidInsufficientBalance_500';
export const IMEI_CHECK_IS_NOT_AVAILABLE = 'ImeiCheckIsNotAvailable_500';
export const DEALER_CODE = '123456';
export const DELIVERY_METHOD_PICK_UP_IN_STORE = 'pickUpInStore';
export const QUERY_PARAM_ORDER_SUMMARY_PAGE = 'ORDER_SUMMERY_PAGE';
export const IS_SMARTWATCH = 'SmartWatch Main';
export const ORDER_ACTIONS = {
	AD: 'add',
	RP: 'replace',
	RM: 'delete'
};
export const MANAGE_YOUR_ADDONS_STEP_LENGTH = 3;
export const MANAGE_YOUR_ADDONS_STEP = 'MANAGE_YOUR_ADDONS';
export const ORDER_SEMMERY_STEP = 'ORDER_SUMMARY';
export const DELIVERY_AND_PAYMENT_STEP = 'DELIVERY_AND_PAYMENT';
export const DELIVERY_ORDER_ITEM_TYPE = 'deliveryOrderItem';
export const DELIVERY_METHOD_TYPE_FORM = 'DeliveryMethodTypeForm';
export const ADD_ONS_PAYMENTS = {
	BY_CARD: 'card',
	BT_VOUCHER: 'voucher',
	FROM_CASH_CREDIT: 'balance',
	NEW_CARD: 'New Card',
	VOUCHER: 'Voucher',
	CARD_PAYMENT: 'Card payment'
};
export const ADDON_PURCHASE_FORM_NAME = 'addonPurchaseFlowForm';
export const PREPAY_VARIATIONS = [
	'prepay',
	'pay as you go',
	'payg'
];

export const Regex = {
	VALID_DATE: /^(?:(?:31(\/|-|\.)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/|-|\.)(?:0?[13-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/|-|\.)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/|-|\.)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/,
	LINE_BREAK: /[\r\n]/gm,
};
