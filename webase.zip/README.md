# Space Base Hub

`tuk-webase` is a foundational utility library designed to streamline common functions, types, interfaces, and base usage across projects. It provides reusable components, utilities, and configurations to enhance consistency and efficiency.

## Installation

```sh
npm install tuk-webase
```

or with Yarn:

```sh
yarn add tuk-webase
```

## Features

- Common utility functions
- TypeScript interfaces and types
- Predefined components (e.g., modals, notifications, error handling)
- Centralized state management hooks
- General constants and helper functions

## Usage

### Importing Utilities

```ts
import { isEmptyString, isUndefinedOrNull } from 'tuk-webase';

console.log(isEmptyString('')); // true
console.log(isUndefinedOrNull(null)); // true
```

### Using Components

```tsx
import { Modal, Notify } from 'tuk-webase';

<Modal open={true} onClose={() => console.log('Closed')}>
  <p>Modal Content</p>
</Modal>
```

```tsx
import { Alert } from '@mui/material';

<Alert severity="error">This is an error alert</Alert>
```

### Error Handler

```tsx
import ErrorHandler from 'tuk-webase';

<ErrorHandler type="alert" status={500} />;
```

## Configuration

Ensure your project includes the necessary peer dependencies, such as React and Material UI:

```json
"peerDependencies": {
  "react": "^18.0.0",
  "react-dom": "^18.0.0",
  "@mui/material": "^5.0.0"
}
