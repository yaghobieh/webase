import { execSync } from "child_process";
import { basename } from "path";

const checkFileNames = () => {
    const changedFiles = execSync("git diff --cached --name-only", { encoding: "utf-8" })
        .split("\n")
        .filter(Boolean);

    const invalidFiles = changedFiles.filter((filePath) => {
        const fileName = basename(filePath);
        return !/^[a-z]/.test(fileName); // Check if the first letter is not lowercase
    });

    if (invalidFiles.length > 0) {
        console.error("The following files must start with a lowercase letter:");
        invalidFiles.forEach((file) => console.error(file));
        process.exit(1);
    }
};

checkFileNames();
