import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { resolve } from "path";
import dts from "vite-plugin-dts";

const projectRootDir = resolve(__dirname, "src");

export default defineConfig({
  build: {
    lib: {
      entry: resolve(__dirname, "src/index.ts"),
      name: "tuk-webase",
      formats: ['es', 'umd'],
      fileName: (format) => `index.${format}.js`,
    },
    minify: true,
    sourcemap: true,
    emptyOutDir: true,
    rollupOptions: {
      external: ["react", "react-dom"],
      output: {
        globals: {
          react: "React",
          "react-dom": "ReactDOM",
        },
      },
    },
  },
  optimizeDeps: {
    include: ['tuk-webase'],
  },
  resolve: {
    alias: [
      { find: "@constants", replacement: resolve(projectRootDir, "src/constants") },
      { find: "@functions", replacement: resolve(projectRootDir, "src/functions") },
      { find: "@types", replacement: resolve(projectRootDir, "src/types") },
      { find: "@hooks", replacement: resolve(projectRootDir, "src/hooks") },
      { find: "@base", replacement: resolve(projectRootDir, "src/base") }
    ],
  },
  plugins: [
    react(),
    dts({
      outputDir: 'dist',
      insertTypesEntry: true,
      tsConfigFilePath: './tsconfig.json',
    })
  ],
});
