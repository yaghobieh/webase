# ✨ tuk-cli-master

A powerful CLI tool to **generate React components and pages** with customizable templates, exports, and route integrations. Ideal for large-scale applications with multiple entry points like `self-service` and `retail`.

## 🎓 Installation

```bash
npm install -D tuk-cli-master
```

> Make sure it's installed as a dev dependency.

Additionally, ensure the following scripts are added to your `package.json`:

```json
{
  "scripts": {
    "tuk:check-version": "tuk-cli-master tuk --checkVersion",
    "create:page": "tuk-cli-master tuk --newPage",
    "create:component": "tuk-cli-master tuk --common",
    "create:actions": "tuk-cli-master tuk --createActions"
  }
}
```

## ⚡ Features

- Quickly scaffold:
    - ✅ Common Components (Business / Controller types)
    - ✅ Pages with routes
- Auto-generates:
    - Component folder with `.tsx`, `.types.ts`, `index.ts`
    - Pages with storybook files
- Automatically adds exports to `index.ts`
- Automatically adds routes to:
    - `RoutesPath.ts`
    - `self-service` or `retail` application route loaders

---

## 🔧 Usage

### 1. Check Versions

```bash
npm run tuk:check-version
```
Checking versions of installed packages...

### 2. Generate a Component

```bash
node node_modules/tuk-cli-master/scripts/create-component.js
```

#### Example:
```
? Please enter Component name: my-button
? Please select the type:
  1. Business
  2. Controllers
```

Auto-generates component files in:
```
src/common-components/business/MyButton/
```

Includes:
- `MyButton.tsx`
- `MyButton.types.ts`
- `index.ts` (with export added to parent index)

### 3. Generate a Page

```bash
node node_modules/tuk-cli-master/scripts/create-page.js
```

#### Example:
```
? Please enter Page name: home-dashboard
? Do you want to add a route? yes
? Please enter the route name: dashboard-home
? Choose app type(s): 1 (Self-service) / 2 (Retail) / 3 (Both)
```
### 4. Generate a Provider

```bash
node node_modules/tuk-cli-master/scripts/create-page.js
```

Creates folder:
```
src/pages/HomeDashboard/
```
And updates:
- `RoutesPath.ts`
- `applications/self-service/routes/index.tsx`
- `applications/retail/routes/index.tsx`

### 5. Generate a Redux Slice
```bash
node node_modules/tuk-cli-master/scripts/createReduxSlice.js
```

---

## 💡 Folder Structure (Templates)

You can customize templates in:
```
node_modules/tuk-cli-master/templates/
```

- `templates/CommonComponent/*`
- `templates/ComponentTemplate/*`

Use placeholders like `CommonComponent` or `ComponentTemplate` that will be replaced automatically by your input.

---

## 🖇 Development / CLI Extension
You can create new scripts inside `scripts/` and execute them via `node` or `npm run` if added to `package.json`.

---

## ✨ Contribution
PRs welcome if you're customizing tuk-cli-master for your internal design systems or component libraries.

---

## 📊 Example Output
```tsx
// src/common-components/business/MyComponent/MyComponent.tsx
export const MyComponent = () => <div className="mycomponent">Hello</div>;

// src/pages/HomeDashboard/HomeDashboard.tsx
// with lazy-loaded routes added automatically
```

---

## 🚀 Next Steps
- Add unit test scaffolds?
- Auto-import in Storybook?
- Integrate Tailwind or MUI per project style?

---

Built with ❤ by TUK team.

