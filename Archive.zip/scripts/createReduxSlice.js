import fs from 'fs';
import path from 'path';
import readline from 'readline';
import chalk from 'chalk';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const prefixFolder = process.cwd() + '/node_modules/tuk-cli-master';

function toPascalCase(str) {
    return str
        .replace(/[-_]/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join('');
}

rl.question(chalk.hex('#00FF85')('Please enter Slice name: '), async (input) => {
    const sliceName = toPascalCase(input);
    console.log('🚀 Starting to create a Redux slice...');
    await createSliceProgress(sliceName);
});

async function createSliceProgress(sliceName) {
    const sliceNameLower = sliceName.charAt(0).toLowerCase() + sliceName.slice(1);
    const newSliceDir = path.join(process.cwd(), 'src', 'actions', sliceNameLower);

    if (fs.existsSync(newSliceDir)) {
        rl.question(chalk.hex('#00FF85')('--Slice already exists. Do you want to change the slice name? (yes/no): '), async (answer) => {
            if (answer.toLowerCase() === 'yes' || answer.toLowerCase() === 'y') {
                rl.question(chalk.hex('#00FF85')('Please enter the new slice name: '), async (input) => {
                    const newSliceName = toPascalCase(input);
                    await createSliceProgress(newSliceName);
                });
            } else {
                console.log(chalk.red('❌ Slice creation aborted.'));
                rl.close();
            }
        });
    } else {
        await proceedWithSliceCreation(sliceName, sliceNameLower, newSliceDir);
    }
}

async function proceedWithSliceCreation(sliceName, sliceNameLower, newSliceDir) {
    const templateDir = path.join(prefixFolder, 'templates', 'ReduxSlice');

    if (!fs.existsSync(newSliceDir)) {
        fs.mkdirSync(newSliceDir, { recursive: true });
    }

    const templateFiles = fs.readdirSync(templateDir);

    for (const file of templateFiles) {
        const newFileName = file.replace(/YourReduxSlice/g, sliceName);
        const content = await fs.promises.readFile(path.join(templateDir, file), 'utf8');
        const newContent = content.replace(/YourReduxSlice/g, sliceName);
        await fs.promises.writeFile(path.join(newSliceDir, newFileName), newContent);
    }

    console.log(chalk.green(`✨ Redux slice created successfully with name: ${sliceName}`));

    await addImportToActionsIndex(sliceName);
    rl.close();
}

async function addImportToActionsIndex(sliceName) {
    const actionsIndexPath = path.join(process.cwd(), 'src', 'actions', 'index.ts');
    let actionsIndexContent = await fs.promises.readFile(actionsIndexPath, 'utf8');

    const sliceNameLower = sliceName.charAt(0).toLowerCase() + sliceName.slice(1);

    // Add imports for State and Saga
    const importStatements = `import { ${sliceName}State } from './${sliceNameLower}/interface';\nimport { ${sliceName}Saga } from './${sliceNameLower}';\n// Your new Redux Slice imports should be added here ** do not remove **`;
    actionsIndexContent = actionsIndexContent.replace('// Your new Redux Slice imports should be added here ** do not remove **', importStatements);

    // Add State Interface
    const stateInterface = `${sliceNameLower}: ${sliceName}State;\n    // Add your new Redux Slice state interfaces here ** do not remove **`;
    actionsIndexContent = actionsIndexContent.replace('// Add your new Redux Slice state interfaces here ** do not remove **', stateInterface);

    // Add Reducer
    const reducerStatement = `${sliceNameLower}: require('./${sliceNameLower}').reducer,\n    // Add your new Reducer Slice state interfaces here ** do not remove **`;
    actionsIndexContent = actionsIndexContent.replace('// Add your new Reducer Slice state interfaces here ** do not remove **', reducerStatement);

    // Add Saga
    const sagaStatement = `yield all([fork(${sliceName}Saga)]);\n    // Add your new Fork Redux Slice sagas here ** do not remove **`;
    actionsIndexContent = actionsIndexContent.replace('// Add your new Fork Redux Slice sagas here ** do not remove **', sagaStatement);

    await fs.promises.writeFile(actionsIndexPath, actionsIndexContent);
    console.log(chalk.green(`✨ Redux slice imports, state, reducer, and saga added successfully for ${sliceName}!`));
}
