#!/usr/bin/env node
import chalk from 'chalk';
import fetch from 'node-fetch';
import fs from 'fs';

const projectName = chalk.bold.cyan('3UK Version Controller');

const drawBox = (lines) => {
    const stripColor = (text) => text.replace(/\x1B\[[0-9;]*m/g, ''); // Regex to remove ANSI escape codes
    const maxLength = Math.max(...lines.map(line => stripColor(line).length));
    const horizontalBorder = '═'.repeat(maxLength + 4);

    console.log(chalk.greenBright(`╔${horizontalBorder}╗`));
    lines.forEach(line => {
        const padding = ' '.repeat(maxLength - stripColor(line).length);
        console.log(chalk.greenBright(`║  ${line}${padding}  ║`));
    });
    console.log(chalk.greenBright(`╚${horizontalBorder}╝`));
};

const libraries = [
    '@material-ui/core',
    '@material-ui/icons',
    '@material-ui/lab',
    '@material-ui/pickers',
    'react',
    'react-dom',
    'typescript',
    'tuk-component-library',
    'tuk-cli-master',
    'tuk-localize-redux',
    'tuk-webase'
];

const allPackages = [...libraries];

const fetchPackageVersion = async (packageName) => {
    const url = `http://incetuk003:8081/nexus/content/groups/hrm-npm-group/${packageName}`;

    try {
        const response = await fetch(url);
        if (!response.ok) {
            console.log(chalk.yellow(`⚠️  Could not fetch version for ${packageName}. Response status: ${response.status}`));
            return null;
        }

        const latestVersion = await response.json();
        const allVersions = Object.keys(latestVersion.versions).sort((a, b) => {
            return a.localeCompare(b, undefined, { numeric: true });
        });
        return allVersions[allVersions.length - 1];
    } catch (error) {
        console.error(chalk.red(`❌ Error fetching ${packageName}`), error);
        return null;
    }
};

const compareVersions = (localVersion, remoteVersion) => {
    const [localMajor, localMinor, localPatch] = localVersion.split('.').map(Number);
    const [remoteMajor, remoteMinor, remotePatch] = remoteVersion.split('.').map(Number);

    if (localMajor !== remoteMajor) {
        return 'danger';
    }

    if (localMinor !== remoteMinor) {
        return 'warning';
    }

    if (localPatch < remotePatch) {
        return 'warning';
    }

    return 'up-to-date';
};

const checkVersions = async () => {
    const outdatedPackages = [];
    const spinner = chalk.greenBright('⏳ Checking versions...');

    console.log(spinner);

    for (const packageName of allPackages) {
        const latestVersion = await fetchPackageVersion(packageName);
        if (!latestVersion) continue;

        const localPackageJsonPath = `node_modules/${packageName}/package.json`;
        if (!fs.existsSync(localPackageJsonPath)) {
            console.log(chalk.yellow(`⚠️  ${packageName} is not installed locally.`));
            continue;
        }

        const localPackageJson = JSON.parse(fs.readFileSync(localPackageJsonPath, 'utf-8'));
        const localVersion = localPackageJson.version;

        const status = compareVersions(localVersion, latestVersion);
        if (status === 'danger' || status === 'warning') {
            outdatedPackages.push({ packageName, localVersion, latestVersion });
        }
    }

    if (outdatedPackages.length > 0) {
        console.log(chalk.yellow('\n⚠️ Found outdated 3UK packages:'));
        drawBox(
            outdatedPackages.map(({ packageName, localVersion, latestVersion }) => {
                return `${chalk.red('(!) ')}${chalk.bold(packageName)}: Current ${chalk.yellow(localVersion)} Latest ${chalk.green(latestVersion)}`;
            })
        );
    } else {
        console.log(chalk.greenBright('✅ All packages are up-to-date!'));
    }
};


const printHeader = (message) => {
    console.log(chalk.greenBright('='.repeat(50)));
    console.log(chalk.greenBright(`🚀 ${projectName} - ${message}`));
    console.log(chalk.greenBright('='.repeat(50)));
};

const printFooter = () => {
    console.log(chalk.greenBright('='.repeat(50)));
    console.log(chalk.greenBright(`✅ ${projectName} - Task completed successfully!`));
    console.log(chalk.greenBright('='.repeat(50)));
};

printHeader('Starting Development Server...');
await checkVersions();
printFooter();
