import fs from 'fs';
import path from 'path';
import readline from 'readline';
import chalk from 'chalk';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const prefixFolder = process.cwd() + '/node_modules/tuk-cli-master';

function toCamelCase(str) {
    return str
        .replace(/[-_]/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join('');
}

rl.question(chalk.hex('#00FF85')('Please enter Component Component name: '), async (input) => {
    const componentName = toCamelCase(input);
    console.log('🚀 Starting to create a component...');
    await createComponentProgress(componentName);
});

async function createComponentProgress(componentName) {
    console.log(chalk.hex('#00FF85')('Please select the type:'));
    console.log('1. Business');
    console.log('2. Controllers');

    rl.question(chalk.hex('#00FF85')('Enter your choice (1 or 2): '), async (choice) => {
        let type;

        switch (choice) {
            case '1':
                type = 'business';
                break;
            case '2':
                type = 'controllers';
                break;
            default:
                console.log('Invalid choice.');
                rl.close();
                return;
        }

        const newComponentDir = path.join(process.cwd(), 'src', 'common-components', type, componentName);

        if (fs.existsSync(newComponentDir)) {
            rl.question(chalk.hex('#00FF85')('--Directory already exists. Do you want to change the component name? (yes/no): '), async (answer) => {
                if (answer.toLowerCase() === 'yes' || answer.toLowerCase() === 'y') {
                    rl.question(chalk.hex('#00FF85')('Please enter the new component name: '), async (input) => {
                        const newComponentName = toCamelCase(input);
                        await createComponentProgress(newComponentName);
                    });
                } else {
                    await proceedWithComponentCreation(componentName, newComponentDir, type);
                }
            });
        } else {
            await proceedWithComponentCreation(componentName, newComponentDir, type);
        }
    });
}

async function proceedWithComponentCreation(componentName, newComponentDir, type) {
    const templateDir = path.join(prefixFolder, 'templates', 'CommonComponent');

    if (!fs.existsSync(newComponentDir)) {
        fs.mkdirSync(newComponentDir, { recursive: true });
    }

    const templateFiles = ['CommonComponent.tsx', 'CommonComponent.types.ts', 'index.ts'];

    for (const file of templateFiles) {
        const newFileName = file.replace('CommonComponent', componentName);
        const content = await fs.promises.readFile(path.join(templateDir, file), 'utf8');
        let newContent = content.replace(/commonComponent/g, componentName);
        newContent = newContent.replace(/className="commonComponent"/g, `className="${componentName.toLowerCase()}"`);
        await fs.promises.writeFile(path.join(newComponentDir, newFileName), newContent);
    }

    await addExportToIndex(componentName, type);
    console.log('✨ Component created successfully!');
    rl.close();
}

async function addExportToIndex(componentName, type) {
    const indexPath = path.join(process.cwd(), 'src', 'common-components', type, 'index.ts');
    let indexContent = await fs.promises.readFile(indexPath, 'utf8');

    const exportStatement = `export { default as ${componentName} } from './${componentName}';\n// New components will be added here ** Do not remove this line **`;

    indexContent = indexContent.replace('// New components will be added here ** Do not remove this line **', exportStatement);

    await fs.promises.writeFile(indexPath, indexContent);
    console.log('✨ Export added to index.ts successfully!');
}
