import fs from 'fs';
import path from 'path';
import chalk from 'chalk';
import inquirer from 'inquirer';

// Utility functions
function toPascalCase(str) {
    return str
        .replace(/[-_]/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join('');
}

function toUpperSnakeCase(str) {
    return str
        .replace(/([a-z])([A-Z])/g, '$1_$2')
        .replace(/[-\s]/g, '_')
        .toUpperCase();
}

function validateActionName(actionName) {
    const regex = /^[a-zA-Z]+([-_][a-zA-Z]+)*$/;
    return regex.test(actionName);
}

async function getSliceName() {
    const actionsDir = path.join(process.cwd(), 'src', 'actions');
    const folders = fs.readdirSync(actionsDir).filter(folder => fs.statSync(path.join(actionsDir, folder)).isDirectory());

    const { sliceName } = await inquirer.prompt([
        {
            type: 'list',
            name: 'sliceName',
            message: 'Choose a slice folder or type a new name:',
            choices: [...folders, 'Enter manually'],
        },
    ]);

    if (sliceName === 'Enter manually') {
        const { manualSliceName } = await inquirer.prompt([
            {
                type: 'input',
                name: 'manualSliceName',
                message: 'Enter the slice folder name:',
            },
        ]);
        return manualSliceName;
    }

    return sliceName;
}

async function askSliceName() {
    const sliceName = await getSliceName();

    const { actionName } = await inquirer.prompt([
        {
            type: 'input',
            name: 'actionName',
            message: 'Please enter your action name (ex: name-name, NameName, or name_name):',
            validate: (input) => validateActionName(input) || 'Invalid action name format. Please try again.',
        },
    ]);

    console.log(chalk.green(`✨ Slice: ${sliceName}, Action: ${actionName}`));
    await addActionToSlice(sliceName, actionName);
}

async function updateSagaFile(sagaPath) {
    let sagaContent = await fs.promises.readFile(sagaPath, 'utf8');
    const watcherFunction = `function* watchJohnTestNow() {\n    yield takeLatest(TypesNames.JOHN_TEST_NOW, JohnTestNowHandler);\n}\n`;

    const firstFunctionIndex = sagaContent.indexOf('function*');
    sagaContent = [
        sagaContent.slice(0, firstFunctionIndex),
        watcherFunction,
        sagaContent.slice(firstFunctionIndex)
    ].join('');

    const sagaRegex = /export function\* specialOffersSaga\(\) \{\n([\s\S]*?)\n\}/;
    const match = sagaContent.match(sagaRegex);

    if (match) {
        const updatedSaga = match[0].replace(
            /yield all\(\[/,
            `yield all([\n\t\tfork(watchJohnTestNow),`
        );
        sagaContent = sagaContent.replace(sagaRegex, updatedSaga);
    } else {
        console.log(chalk.red(`❌ specialOffersSaga not found in "${sagaPath}".`));
        return;
    }

    await fs.promises.writeFile(sagaPath, sagaContent);
    console.log(chalk.green(`✨ Updated saga.js with watcher, handler, and fork for JohnTestNow.`));
}

async function updateWatcherFunction(actionsIndexPath, actionName) {
    let actionsIndexContent = await fs.promises.readFile(actionsIndexPath, 'utf8');
    const pascalActionName = toPascalCase(actionName);

    const watcherFunction = `function* watch${pascalActionName}() {\n    yield takeLatest(TypesNames.${toUpperSnakeCase(actionName)}, createSaga(Sagas.${pascalActionName}Handler));\n}\n`;
    const forkStatement = `fork(watch${pascalActionName}),\n        // Add your new Fork Redux Slice sagas here ** do not remove **`;

    actionsIndexContent = actionsIndexContent.replace('// Your new Redux Slice watcher functions should be added here ** do not remove **', watcherFunction);
    actionsIndexContent = actionsIndexContent.replace('// Add your new Fork Redux Slice sagas here ** do not remove **', forkStatement);

    await fs.promises.writeFile(actionsIndexPath, actionsIndexContent);
    console.log(chalk.green(`✨ Updated index.js with watcher and fork for action '${actionName}'.`));
}

async function moveHandlerFunction(sagaPath, functionName) {
    const handlerFunction = `
export function* ${functionName}() {
    try {
        console.log("Handling ${functionName}...");
        // Add your saga logic here
    } catch (error) {
        console.error("Error in ${functionName}:", error);
    }
}
`;

    let sagaContent = await fs.promises.readFile(sagaPath, 'utf8');
    sagaContent += `\n${handlerFunction}`;

    await fs.promises.writeFile(sagaPath, sagaContent);
    console.log(chalk.green(`✨ Added ${functionName} to the bottom of "${sagaPath}".`));
}

async function addActionToSlice(sliceName, actionName) {
    const sliceDir = path.join(process.cwd(), 'src', 'actions', sliceName.toLowerCase());
    const interfacePath = path.join(sliceDir, 'interface.ts');
    const reduxActionPath = path.join(sliceDir, 'redux.ts');
    const indexPath = path.join(sliceDir, 'index.ts');
    const sagaPath = path.join(sliceDir, 'sagas.ts');

    if (!fs.existsSync(sliceDir)) {
        console.log(chalk.red(`❌ Slice folder "${sliceName}" not found. Please try again.`));
        return;
    }

    await updateInterfaceFile(interfacePath, actionName);
    await updateReduxFile(interfacePath, actionName);
    await updateReduxActions(reduxActionPath, actionName);
    await updateSagaFile(indexPath, actionName);
    await updateWatcherFunction(indexPath, actionName);
    await moveHandlerFunction(sagaPath, actionName);
}

async function updateInterfaceFile(interfacePath, actionName) {
    let interfaceContent = await fs.promises.readFile(interfacePath, 'utf8');
    const pascalActionName = toPascalCase(actionName);

    const typesNamesEnum = `export enum TypesNames {\n`;
    const typesNamesInsert = `${toUpperSnakeCase(actionName)} = '${toUpperSnakeCase(actionName)}',\n`;
    interfaceContent = interfaceContent.replace(typesNamesEnum, `${typesNamesEnum}${typesNamesInsert}`);

    const actionTypeInsert = `export type ${pascalActionName}Action = Action<TypesNames.${toUpperSnakeCase(actionName)}>;\n`;
    const firstExportTypeIndex = interfaceContent.indexOf('export type');
    if (firstExportTypeIndex !== -1) {
        interfaceContent = [
            interfaceContent.slice(0, firstExportTypeIndex),
            actionTypeInsert,
            interfaceContent.slice(firstExportTypeIndex)
        ].join('');
    } else {
        interfaceContent += `\n${actionTypeInsert}`;
    }

    const functionDeclarationInsert = `export declare function ${pascalActionName}Function(): ${pascalActionName}Action;\n`;
    const firstExportDeclareIndex = interfaceContent.indexOf('export declare function');
    if (firstExportDeclareIndex !== -1) {
        interfaceContent = [
            interfaceContent.slice(0, firstExportDeclareIndex),
            functionDeclarationInsert,
            interfaceContent.slice(firstExportDeclareIndex)
        ].join('');
    } else {
        interfaceContent += `\n${functionDeclarationInsert}`;
    }

    await fs.promises.writeFile(interfacePath, interfaceContent);
    console.log(chalk.green(`✨ Updated interface.ts with action "${actionName}".`));
}

async function updateReduxFile(interfacePath, actionName) {
    let reduxContent = await fs.promises.readFile(interfacePath, 'utf8');
    const camelActionName = toPascalCase(actionName).charAt(0).toLowerCase() + toPascalCase(actionName).slice(1);

    const actionCreatorRegex = /export interface ActionCreator \{([\s\S]*?)\}/;
    const match = reduxContent.match(actionCreatorRegex);

    if (!match) {
        console.log(chalk.red(`❌ ActionCreator interface not found in "${interfacePath}".`));
        return;
    }

    const updatedInterface = match[0].replace(
        '{',
        `{\n    ${camelActionName}: typeof ${toPascalCase(actionName)}Function;`
    );
    reduxContent = reduxContent.replace(actionCreatorRegex, updatedInterface);

    await fs.promises.writeFile(interfacePath, reduxContent);
    console.log(chalk.green(`✨ Updated redux.ts with action "${actionName}".`));
}

async function updateReduxActions(reduxPath, actionName) {
    let reduxContent = await fs.promises.readFile(reduxPath, 'utf8');
    const camelActionName = toPascalCase(actionName).charAt(0).toLowerCase() + toPascalCase(actionName).slice(1);

    const creatorsBlockRegex = /const \{ Creators \} = createActions<TypesNames, ActionCreator>\(\{([\s\S]*?)\}\);/;
    const match = reduxContent.match(creatorsBlockRegex);

    if (!match) {
        console.log(chalk.red(`❌ Creators block not found in '${reduxPath}'.`));
        return;
    }

    const updatedCreatorsBlock = match[0].replace(
        /createActions<TypesNames, ActionCreator>\(\{/,
        `createActions<TypesNames, ActionCreator>({\n    ${camelActionName}: [],`
    );
    reduxContent = reduxContent.replace(creatorsBlockRegex, updatedCreatorsBlock);

    await fs.promises.writeFile(reduxPath, reduxContent);
    console.log(chalk.green(`✨ Updated redux.ts with action '${actionName}' under Creators block.`));
}

// Start the process
askSliceName();
