import fs from 'fs';
import path from 'path';
import readline from 'readline';
import chalk from 'chalk';

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const prefixFolder = process.cwd() + '/node_modules/tuk-cli-master';

function toCamelCase(str) {
    return str
        .replace(/[-_]/g, ' ')
        .split(' ')
        .map(word => word.charAt(0).toUpperCase() + word.slice(1))
        .join('');
}

rl.question(chalk.hex('#00FF85')('Please enter Page name: '), async (input) => {
    const componentName = toCamelCase(input);
    console.log('🚀 Starting to create a page...');
    await createComponentProgress(componentName);
});

async function createComponentProgress(componentName) {
    const newComponentDir = path.join(process.cwd(), 'src', 'pages', componentName);

    if (fs.existsSync(newComponentDir)) {
        rl.question(chalk.hex('#00FF85')('--Directory already exists. Do you want to change the page name? (yes/no): '), async (answer) => {
            if (answer.toLowerCase() === 'yes' || answer.toLowerCase() === 'y') {
                rl.question(chalk.hex('#00FF85')('Please enter the new component name: '), async (input) => {
                    const newComponentName = toCamelCase(input);
                    await createComponentProgress(newComponentName);
                });
            } else {
                await proceedWithComponentCreation(componentName, newComponentDir);
            }
        });
    } else {
        await proceedWithComponentCreation(componentName, newComponentDir);
    }
}

async function proceedWithComponentCreation(componentName, newComponentDir) {
    rl.question(chalk.hex('#00FF85')('--Is this a Provider? (yes/no): '), async (isProvider) => {
        const isProviderFlag = isProvider.toLowerCase() === 'yes' || isProvider.toLowerCase() === 'y';
        const finalComponentName = isProviderFlag ? `${componentName}q` : componentName;
        const templateDir = isProviderFlag
            ? path.join(prefixFolder, 'templates', 'provider')
            : path.join(prefixFolder, 'templates', 'ComponentTemplate');

        if (!fs.existsSync(newComponentDir)) {
            fs.mkdirSync(newComponentDir, { recursive: true });
        }

        const templateFiles = fs.readdirSync(templateDir);

        for (const file of templateFiles) {
            const newFileName = file.replace(/ComponentName/g, finalComponentName);
            const content = await fs.promises.readFile(path.join(templateDir, file), 'utf8');
            const newContent = content.replace(/ComponentName/g, finalComponentName);
            await fs.promises.writeFile(path.join(newComponentDir, newFileName), newContent);
        }

        console.log(chalk.green(`✨ ${isProviderFlag ? 'Provider' : 'Component'} created successfully with name: ${finalComponentName}`));

        await addNewRoute(finalComponentName);
        await addTranslation(finalComponentName);
        await addImportToPagesIndex(finalComponentName);
    });
}

async function addNewRoute(componentName) {
    return new Promise((resolve) => {
        rl.question(chalk.hex('#00FF85')('--Do you want to add new route? (yes/no): '), async (answer) => {
            if (answer.toLowerCase() === 'yes' || answer.toLowerCase() === 'y') {
                rl.question(chalk.hex('#00FF85')('Please enter the new route name (single word or hyphen-separated): '), async (input) => {
                    const newRouteName = input.toUpperCase().replace(/ /g, '_').replace(/-/g, '_');
                    if (/^[A-Z0-9_]+$/.test(newRouteName)) {
                        const routePath = path.join(process.cwd(), 'src', 'routes', 'RoutesPath.ts');
                        let routeContent = await fs.promises.readFile(routePath, 'utf8');
                        const newRoute = `${newRouteName} = '/${input.toLowerCase()}',\n// New routes ** do not remove **`;
                        routeContent = routeContent.replace('// New routes ** do not remove **', newRoute);

                        await fs.promises.writeFile(routePath, routeContent);
                        console.log('✨ Route added! Destination set for new worlds!');
                    } else {
                        console.log('Invalid route name. Only letters, numbers and underscores are allowed.');
                    }
                    resolve();
                });
            } else {
                resolve();
            }
        });
    }).then(() => {
        console.log('✨ Component created successfully!');
    });
}

async function addTranslation(componentName) {
    return new Promise((resolve) => {
        rl.question(chalk.hex('#00FF85')('--Do you want to add a translation key? (yes/no): '), async (answer) => {
            if (answer.toLowerCase() === 'yes' || answer.toLowerCase() === 'y') {
                const enJsonPath = path.join(process.cwd(), 'src', 'translation', 'json', 'en.json');
                if (!fs.existsSync(enJsonPath)) {
                    console.log(chalk.red('❌ en.json file not found.'));
                    resolve();
                    return;
                }

                const enJsonContent = JSON.parse(await fs.promises.readFile(enJsonPath, 'utf8'));
                const translationKey = componentName.charAt(0).toLowerCase() + componentName.slice(1);

                if (enJsonContent[translationKey]) {
                    console.log(chalk.yellow(`⚠️ Translation key "${translationKey}" already exists in en.json.`));
                } else {
                    enJsonContent[translationKey] = {};
                    const commentKey = '_comment';
                    if (enJsonContent[commentKey]) {
                        const commentIndex = Object.keys(enJsonContent).indexOf(commentKey);
                        const updatedContent = Object.entries(enJsonContent).reduce((acc, [key, value], index) => {
                            if (index === commentIndex) {
                                acc[key] = value;
                                acc[translationKey] = {};
                            } else {
                                acc[key] = value;
                            }
                            return acc;
                        }, {});
                        await fs.promises.writeFile(enJsonPath, JSON.stringify(updatedContent, null, 2));
                    } else {
                        enJsonContent[translationKey] = {};
                        await fs.promises.writeFile(enJsonPath, JSON.stringify(enJsonContent, null, 2));
                    }
                    console.log(chalk.green(`✨ Translation key "${translationKey}" added to en.json.`));
                }
            }
            resolve();
        });
    });
}

async function addImportToPagesIndex(componentName) {
    console.log(chalk.hex('#00FF85')('Please select the application type(s):'));
    console.log('1. Self-service');
    console.log('2. Retail');
    console.log('3. Both');

    rl.question(chalk.hex('#00FF85')('Enter your choice (1, 2, or 3): '), async (choice) => {
        let applicationTypes = [];

        switch (choice) {
            case '1':
                applicationTypes = ['self-service'];
                break;
            case '2':
                applicationTypes = ['retail'];
                break;
            case '3':
                applicationTypes = ['self-service', 'retail'];
                break;
            default:
                console.log('Invalid choice.');
                rl.close();
                return;
        }

        for (const type of applicationTypes) {
            const pagesIndexPath = path.join(process.cwd(), 'src', 'applications', type, 'routes', 'index.tsx');
            let pagesIndexContent = await fs.promises.readFile(pagesIndexPath, 'utf8');

            const importStatement = `const ${componentName} = lazy(() => import(/* webpackChunkName: "${componentName.toLowerCase()}" */ 'pages/${componentName}'));\n// Import will be added new routes here ** do not remove **`;
            const routeStatement = `<Route exact path={RoutesPath.${componentName.toUpperCase()}} component={${componentName}} />\n{/* New Route will be add here */`;

            pagesIndexContent = pagesIndexContent.replace('// Import will be added new routes here ** do not remove **', importStatement);
            pagesIndexContent = pagesIndexContent.replace('{/* New Route will be add here */', routeStatement);

            await fs.promises.writeFile(pagesIndexPath, pagesIndexContent);
            console.log(`✨ Import and route added to ${type} index.tsx successfully!`);
        }
        rl.close();
    });
}
