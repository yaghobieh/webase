import { ReactNode } from 'react';

export type ComponentNameType = { }

export type ComponentNameProps = {
    children: ReactNode;
}
