import React, { createContext, useContext, useMemo } from 'react';
import { ComponentNameType, ComponentNameProps } from './ComponentName.types';

const ComponentNameContext = createContext<ComponentNameType | undefined>(undefined);

export const ComponentNameProvider: React.FC<ComponentNameProps> = (props: ComponentNameProps) => {
    const { children } = props;

    const values = useMemo(() => ({
       // You input the necessary properties and methods here
    }), []);

    return (
        <ComponentNameContext.Provider value={values}>
            {children}
        </ComponentNameContext.Provider>
    );
};

export const useComponentName = (): ComponentNameType => {
    const context = useContext(ComponentNameContext);
    if (!context) {
        throw new Error('useComponentName must be used within a ComponentNameProvider');
    }
    return context;
};
