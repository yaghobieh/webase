import React from 'react';
import { ComponentNameProvider } from "./ComponentName.provider";

const ComponentNameMain: React.FC = () => {

    return (
        <ComponentNameProvider>
            <div>Start here</div>
        </ComponentNameProvider>
    );
};

export default ComponentNameMain;
