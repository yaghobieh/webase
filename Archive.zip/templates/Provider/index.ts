export * from './ComponentName.provider';
export * from './ComponentName.main';
export type { ComponentNameType, ComponentNameProps } from './ComponentName.types';
