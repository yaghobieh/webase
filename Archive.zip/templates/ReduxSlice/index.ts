import { all, fork, takeLatest } from 'redux-saga/effects';
import { createSaga } from '@base/features/base-decorator';
import * as Sagas from 'actions/YourReduxSlice/sagas';
import { YourReduxSliceTypes } from 'actions/YourReduxSlice';

/* ------------- Export Redux ------------- */
export * from 'actions/YourReduxSlice/redux';

/* ------------- Export Sagas ------------- */
function* watchYourReduxSliceSaga() {
	yield takeLatest(YourReduxSliceTypes.YOUR_REDUX_COMPONENT_START, createSaga(Sagas.yourReduxSliceStart));
}

export function* YourReduxSliceSaga() {
	yield all([
		fork(watchYourReduxSliceSaga),
	]);
}
