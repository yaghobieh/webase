// Your helper functions will be here
