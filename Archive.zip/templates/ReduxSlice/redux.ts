import { createDraft, Draft } from 'immer';
import { createReducerCase } from '@base/features/base-decorator';
import { createReducer, createActions } from 'reduxsauce';
import {
	TypesNames,
	ActionCreator,
	YourReduxSliceState,
} from './interface';

/* ------------- Types and Action Creators ------------- */

const { Creators } = createActions<TypesNames, ActionCreator>({
	yourReduxSliceStart: [],
});

export const YourReduxSliceTypes = TypesNames;
export const YourReduxSliceActions = Creators;

/* ------------- Initial State ------------- */

const INITIAL_STATE = createDraft<YourReduxSliceState>({});

/* ------------- Reducers ------------- */

const yourReduxSliceInitialStateReducer = () => {
	return INITIAL_STATE;
};

/* ------------- Hookup Reducers To Types ------------- */

export const reducer = createReducer<any, any>(INITIAL_STATE, {
	[TypesNames.CLEAR_STATE]: createReducerCase(yourReduxSliceInitialStateReducer),
});
