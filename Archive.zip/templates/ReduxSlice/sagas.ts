import {
	put, select, take
} from 'redux-saga/effects';

export function* yourReduxSliceStart() {
	yield select((state) => state.yourReduxSlice); // Example of selecting state
	yield take('YOUR_ACTION_TYPE');
	yield put({	type: 'YOUR_REDUCER_ACTION_TYPE', payload: { someData: 'data' } });
}
