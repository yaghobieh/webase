import { Action } from 'redux';

/* ------------- Define Actions and State ------------- */
export interface YourReduxSliceState {
}

export enum TypesNames {
	YOUR_REDUX_SLICE_START = 'YOUR_REDUX_SLICE_START',
}

export declare function YourReduxSliceFunction(): YourReduxSliceStateAction;

export interface ActionCreator {
	yourReduxSliceStart: typeof YourReduxSliceFunction;
}

export type YourReduxSliceStateAction = Action<TypesNames.YOUR_REDUX_SLICE_START>;
