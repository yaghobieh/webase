export const YourReduxSliceSelectors = {
	// Define your selectors here
};
