export type ComponentTemplateType = {

}
