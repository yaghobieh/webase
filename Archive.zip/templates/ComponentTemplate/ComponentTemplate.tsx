import React, { FC } from "react";
import { ComponentTemplateType } from './ComponentTemplate.types';

export const ComponentTemplate: FC<ComponentTemplateType> = (props: ComponentTemplateType) => {
	return (
		<div className="componentTemplate">
			You componentTemplate are ready
		</div>
	)
}

