export * from './CommonComponent';
export type { CommonComponentType } from './CommonComponent.types'
