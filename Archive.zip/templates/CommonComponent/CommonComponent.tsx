import React, { FC } from "react";
import { CommonComponentType } from './CommonComponent.types';

export const CommonComponent: FC<CommonComponentType> = (props: CommonComponentType) => {
    const { style, className = '' } = props;
    return (
        <div className={`commonComponent w-[60%] bg-gray-500 rounded-[8px] p-2 m-2 m-auto ${className}`} style={style}>
            You commonComponent is ready (see tailwind css example)
        </div>
    )
}

