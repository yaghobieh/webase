import { CSSProperties } from 'react';

export type CommonComponentType = {
    // Props definition goes here
    className?: string;
    style?: CSSProperties;
}
