#!/usr/bin/env node
/* jshint esversion: 6, node: true */
import { createRequire } from "module";
import { spawn } from "child_process";
import chalk from "chalk";

const require = createRequire(import.meta.url);
const { version } = require('./package.json');

let scriptsPath = 'node_modules/tuk-cli-master/';
if (process.env.MODE === 'dev') {
    scriptsPath = './';
}


function displayHeader() {
    console.log(chalk.whiteBright("\n=============================="));
    console.log(chalk.hex('#00FF85')(`🚀 3️⃣UK CLI Master`));
    console.log(chalk.whiteBright("==============================\n"));
}

const commandMap = {
    "tuk--newPage": {
        message: "Starting to create new page...",
        script: "scripts/createPage.js"
    },
    "tuk--common": {
        message: "Starting to create new Common Component page...",
        script: "scripts/createCommonComponent.js"
    },
    "tuk--createSlice": {
        message: "Starting to create new Redux Slice...",
        script: "scripts/createReduxSlice.js"
    },
    "tuk--createActions": {
        message: "Starting to create new Redux Action...",
        script: "scripts/createReduxAction.js"
    },
    "tuk--checkVersion": {
        message: "Checking for outdated 3UK packages...",
        script: "scripts/checkVersions.js"
    },
    "--help": {
        message: "Displaying help menu...",
        script: null
    },
    "--release": {
        message: "Displaying release notes...",
        script: null
    }
};

const commands = [
    { Command: 'node index.js tuk --createSlice', Description: 'Create New redux slice' },
    { Command: 'node index.js tuk --checkVersions', Description: 'Check for TUK ext libs versions' },
    { Command: 'node index.js tuk --newPage', Description: 'Create a new Page' },
    { Command: 'node index.js tuk --common', Description: 'Create a new Common Component' },
    { Command: 'node index.js tuk --createActions', Description: 'Create a new Redux Action' },
    { Command: 'node index.js --help', Description: 'Show help menu' },
    { Command: 'node index.js --release', Description: 'Show release notes' },
];

function printTable(commands) {
    const border = "=".repeat(80);
    console.log(border);
    console.log("Command".padEnd(60) + "Description");
    console.log(border);
    commands.forEach(command => {
        console.log(command.Command.padEnd(60) + command.Description);
    });
    console.log(border);
}

function showHelp() {
    console.log(chalk.blue("\nAvailable Commands:"));
    printTable(commands);
}

function showReleaseNotes() {
    const border = "=".repeat(80);
    console.log(chalk.green("\n🚀 Tuk CLI Master - Release Notes"));
    console.log(chalk.whiteBright("\nVersion 1.0.7"));
    console.log(chalk.hex('#FF69B4')("\n🌟 Most Recent Change:"));
    console.log(chalk.hex('#FF69B4')("Enhanced folder selection for Redux actions."));
    console.log(chalk.hex('#FF69B4')("Users can now choose from a list of existing folders or manually enter a new folder name."));
    console.log(border);
    console.log("| Name                                   | Description                              ");
    console.log(border);
    console.log("| Create new Redux slice                 | Effortlessly create a new Redux slice.   ");
    console.log("| Check TUK libraries                    | Automatically check TUK libraries and their versions. ");
    console.log("| Create Retail or Self-Service pages    | Generate pages for Retail or Self-Service. ");
    console.log("| Initialize common components           | Set up common components for Business or Controllers. ");
    console.log("| Create new Redux Action                | Choose from a list of actions for better state management. ");
    console.log(border);
    console.log(chalk.whiteBright("\nEnhancements:"));
    console.log(chalk.yellow("- Improved CLI commands for better usability."));
    console.log(chalk.yellow("- Streamlined folder structure for generated files."));
    console.log(chalk.yellow("- Added full management for Redux actions."));
}

function runScript(scriptPath, additionalArgs = []) {
    if (!scriptPath) return;
    const child = spawn("node", [scriptPath, ...additionalArgs], {
        stdio: "inherit",
    });

    child.on("error", (error) => {
        console.error(chalk.red(`Error executing script: ${error.message}`));
    });

    child.on("close", (code) => {
        if (code !== 0) {
            console.error(chalk.red(`Script exited with code ${code}`));
        } else {
            console.log(chalk.green(`Script executed successfully!`));
        }
    });
}

const nodeVersion = process.version;
const majorVersion = parseInt(nodeVersion.split('.')[0].replace('v', ''), 10);

if (majorVersion < 18) {
    console.error(chalk.hex('#FF69B4')("Error: Node.js version 18 or higher is required to run this CLI."));
    process.exit(1);
}

const args = process.argv.slice(2);
const commandKey = `${args[0]}${args[1] ? `${args[1]}` : ''}`;
const command = commandMap[commandKey];
displayHeader();

if (command) {
    if (commandKey === "--help") {
        showHelp();
    } else if (commandKey === "--release") {
        showReleaseNotes();
    } else {
        if (command.message) {
            console.log(chalk.yellow.bold(command.message));
        }
        runScript(`${scriptsPath}${command.script}`);
    }
} else {
    console.log(chalk.red("Invalid command. Please use one of the following:"));
    printTable(commands);
}
